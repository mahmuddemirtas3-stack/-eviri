package com.oyuncevir.ceviri

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class SettingsHooks(
    val onStyle: () -> Unit = {},
    val onEngine: () -> Unit = {},
    val onPickRegion: (() -> Unit)? = null,
    val onToggleCover: (() -> Unit)? = null,
    val onTogglePause: (() -> Unit)? = null
)

object SubtitleStyle {
    val fontNames = arrayOf("Normal", "Dar", "Orta kalın", "Serif", "Daktilo", "El yazısı")
    private val fontFamilies = arrayOf("sans-serif", "sans-serif-condensed", "sans-serif-medium", "serif", "monospace", "casual")
    val colors = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE066.toInt(), 0xFF7FE3FF.toInt(), 0xFF9FD49B.toInt())

    fun apply(ctx: Context, tv: TextView, ui: UiKit) {
        tv.textSize = Prefs.textSize(ctx).toFloat()
        tv.setTextColor(colors[Prefs.color(ctx).coerceIn(0, colors.size - 1)])
        val fam = fontFamilies[Prefs.font(ctx).coerceIn(0, fontFamilies.size - 1)]
        tv.typeface = Typeface.create(fam, if (Prefs.bold(ctx)) Typeface.BOLD else Typeface.NORMAL)
        val bg = GradientDrawable()
        bg.setColor(Color.argb(Prefs.subBg(ctx) * 255 / 100, 0, 0, 0))
        bg.cornerRadius = ui.dp(10).toFloat()
        tv.background = bg
        tv.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        tv.setShadowLayer(4f, 0f, 2f, 0xFF000000.toInt())
        tv.gravity = Gravity.CENTER
    }
}

object SettingsPanel {
    private val langNames = arrayOf("İngilizce", "Almanca", "Fransızca", "İspanyolca", "İtalyanca", "Portekizce")
    private val langCodes = arrayOf("en", "de", "fr", "es", "it", "pt")
    private val engines = arrayOf("offline", "google", "gemini")

    fun build(ctx: Context, ui: UiKit, hooks: SettingsHooks): LinearLayout {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL

        // ---- Çeviri motoru ----
        val eng = ui.card()
        eng.addView(ui.label("Çeviri motoru", 16f, Pal.TEXT, true), ui.lp(0, 10))
        val geminiBox = LinearLayout(ctx)
        geminiBox.orientation = LinearLayout.VERTICAL
        val langRow = LinearLayout(ctx)
        langRow.orientation = LinearLayout.VERTICAL
        val desc = ui.label("", 12f, Pal.MUTED)

        fun refreshEngine() {
            val e = Prefs.engine(ctx)
            geminiBox.visibility = if (e == "gemini") View.VISIBLE else View.GONE
            langRow.visibility = View.VISIBLE
            desc.text = when (e) {
                "offline" -> "İnternetsiz çalışır, ilk seferde dil modeli iner. Sadece Latin harfli diller."
                "gemini" -> "En doğal çeviri. Kendi API anahtarın gerekir. Hata olursa Google'a geçer."
                else -> "Ücretsiz ve hızlı, internet gerekir. Hata olursa çevrimdışıya geçer."
            }
        }

        val seg = Segmented(ui, ctx, listOf("Çevrimdışı", "Google", "Gemini")) { i ->
            Prefs.setEngine(ctx, engines[i])
            refreshEngine()
            hooks.onEngine()
        }
        seg.select(engines.indexOf(Prefs.engine(ctx)).let { if (it < 0) 1 else it })
        eng.addView(seg.view, ui.lp(0, 8))
        eng.addView(desc, ui.lp(0, 10))

        geminiBox.addView(ui.label("Gemini API anahtarı", 12f, Pal.MUTED), ui.lp(0, 4))
        geminiBox.addView(ui.field("AIza...", Prefs.apiKey(ctx), true) { Prefs.setApiKey(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        geminiBox.addView(ui.label("Model", 12f, Pal.MUTED), ui.lp(0, 4))
        geminiBox.addView(ui.field(Prefs.DEFAULT_MODEL, Prefs.model(ctx), false) { Prefs.setModel(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        geminiBox.addView(ui.tonal("Ücretsiz anahtar al") {
            ctx.startActivity(
                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://aistudio.google.com/apikey"))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }, ui.lp(0, 10))
        eng.addView(geminiBox)

        langRow.addView(ui.label("Oyunun dili", 12f, Pal.MUTED), ui.lp(0, 4))
        val langBtn = ui.tonal("") {}
        fun langText() {
            val idx = langCodes.indexOf(Prefs.srcLang(ctx)).let { if (it < 0) 0 else it }
            langBtn.text = langNames[idx] + "  ▾"
        }
        langBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Oyunun dili").setItems(langNames) { _, which ->
                Prefs.setSrcLang(ctx, langCodes[which])
                langText()
                hooks.onEngine()
            }.show()
        }
        langText()
        langRow.addView(langBtn)
        eng.addView(langRow)
        refreshEngine()
        root.addView(eng, ui.lp(0, 12))

        // ---- Altyazı görünümü ----
        val sub = ui.card()
        sub.addView(ui.label("Altyazı", 16f, Pal.TEXT, true), ui.lp(0, 10))
        val preview = TextView(ctx)
        preview.text = "Örnek altyazı: Buradan çıkmalıyız!"
        val pv = LinearLayout(ctx)
        pv.gravity = Gravity.CENTER
        pv.background = ui.rounded(0xFF3B4A52.toInt(), 14)
        pv.setPadding(ui.dp(10), ui.dp(16), ui.dp(10), ui.dp(16))
        pv.addView(preview)
        sub.addView(pv, ui.lp(0, 12))

        fun restyle() {
            SubtitleStyle.apply(ctx, preview, ui)
            hooks.onStyle()
        }

        val sizeLabel = ui.label("", 13f, Pal.MUTED)
        sub.addView(sizeLabel, ui.lp(0, 2))
        sub.addView(ui.seek(12, 48, Prefs.textSize(ctx)) {
            Prefs.setTextSize(ctx, it)
            sizeLabel.text = "Boyut: $it"
            restyle()
        }, ui.lp(0, 8))
        sizeLabel.text = "Boyut: ${Prefs.textSize(ctx)}"

        sub.addView(ui.label("Konum (yukarı ↔ aşağı)", 13f, Pal.MUTED), ui.lp(0, 2))
        sub.addView(ui.seek(0, 100, Prefs.subPos(ctx)) {
            Prefs.setSubPos(ctx, it)
            hooks.onStyle()
        }, ui.lp(0, 8))

        sub.addView(ui.label("Arka plan koyuluğu", 13f, Pal.MUTED), ui.lp(0, 2))
        sub.addView(ui.seek(0, 100, Prefs.subBg(ctx)) {
            Prefs.setSubBg(ctx, it)
            restyle()
        }, ui.lp(0, 10))

        sub.addView(ui.label("Yazı tipi", 13f, Pal.MUTED), ui.lp(0, 4))
        val fontBtn = ui.tonal("") {}
        fun fontText() {
            fontBtn.text = SubtitleStyle.fontNames[Prefs.font(ctx).coerceIn(0, SubtitleStyle.fontNames.size - 1)] + "  ▾"
        }
        fontBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Yazı tipi").setItems(SubtitleStyle.fontNames) { _, which ->
                Prefs.setFont(ctx, which)
                fontText()
                restyle()
            }.show()
        }
        fontText()
        sub.addView(fontBtn, ui.lp(0, 8))

        val boldBtn = ui.tonal("") {}
        fun boldText() {
            boldBtn.text = if (Prefs.bold(ctx)) "Kalın: Açık" else "Kalın: Kapalı"
        }
        boldBtn.setOnClickListener {
            Prefs.setBold(ctx, !Prefs.bold(ctx))
            boldText()
            restyle()
        }
        boldText()
        sub.addView(boldBtn, ui.lp(0, 10))

        sub.addView(ui.label("Renk", 13f, Pal.MUTED), ui.lp(0, 6))
        val colorRow = LinearLayout(ctx)
        colorRow.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<View>()
        fun chipStates() {
            for ((i, v) in chips.withIndex()) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(SubtitleStyle.colors[i])
                g.setStroke(ui.dp(3), if (i == Prefs.color(ctx)) Pal.ACCENT else Color.TRANSPARENT)
                v.background = g
            }
        }
        for (i in SubtitleStyle.colors.indices) {
            val v = View(ctx)
            v.setOnClickListener {
                Prefs.setColor(ctx, i)
                chipStates()
                restyle()
            }
            chips.add(v)
            val p = LinearLayout.LayoutParams(ui.dp(40), ui.dp(40))
            p.rightMargin = ui.dp(12)
            colorRow.addView(v, p)
        }
        chipStates()
        sub.addView(colorRow)
        SubtitleStyle.apply(ctx, preview, ui)
        root.addView(sub, ui.lp(0, 12))

        // ---- Hız ----
        val spd = ui.card()
        spd.addView(ui.label("Okuma hızı", 16f, Pal.TEXT, true), ui.lp(0, 8))
        val sSeg = Segmented(ui, ctx, listOf("Hızlı", "Dengeli", "Tasarruf")) { Prefs.setSpeed(ctx, it) }
        sSeg.select(Prefs.speed(ctx).coerceIn(0, 2))
        spd.addView(sSeg.view, ui.lp(0, 6))
        spd.addView(ui.label("Hızlı: gecikme en düşük, telefon daha çok çalışır.", 12f, Pal.MUTED))
        root.addView(spd, ui.lp(0, 12))

        // ---- Yayın içi kontroller ----
        val pick = hooks.onPickRegion
        if (pick != null) {
            val st = ui.card()
            st.addView(ui.label("Yayın", 16f, Pal.TEXT, true), ui.lp(0, 10))
            st.addView(ui.primary("Okuma bölgesini seç") { pick() }, ui.lp(0, 8))
            hooks.onToggleCover?.let { f -> st.addView(ui.tonal("Ekranı karart / aç") { f() }, ui.lp(0, 8)) }
            hooks.onTogglePause?.let { f -> st.addView(ui.tonal("Çeviriyi duraklat / sürdür") { f() }) }
            root.addView(st, ui.lp(0, 12))
        }
        return root
    }
}
