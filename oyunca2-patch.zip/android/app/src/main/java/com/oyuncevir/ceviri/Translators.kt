package com.oyuncevir.ceviri

import android.content.Context
import android.text.Html
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Metni çevirir; bloklar. Çevrilemezse null. (GameTranslator, AGPL-3.0, yapısından uyarlanmıştır) */
fun interface TextTranslator {
    fun translate(text: String): String?
}

object TranslateStatus {
    @Volatile var lastError: String? = null
}

/** Google'ın anahtarsız çeviri ucu. İnternet ister. */
class GoogleGtxTranslator(private val source: String, private val target: String) : TextTranslator {
    override fun translate(text: String): String? {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return ""
        val q = URLEncoder.encode(trimmed, "UTF-8")
        val urls = listOf(
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$source&tl=$target&dt=t&q=$q",
            "https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=$source&tl=$target&dt=t&q=$q"
        )
        for (u in urls) {
            val r = fetch(u)
            if (!r.isNullOrBlank()) {
                TranslateStatus.lastError = null
                return r
            }
        }
        TranslateStatus.lastError = "Google çevirisine ulaşılamadı"
        return null
    }

    private fun fetch(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 2500
            c.readTimeout = 3500
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            if (c.responseCode != 200) null
            else parse(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
        } catch (e: Exception) {
            null
        } finally {
            c.disconnect()
        }
    }

    private fun parse(json: String): String? {
        val root = JSONArray(json)
        val sentences = root.optJSONArray(0) ?: return null
        val sb = StringBuilder()
        for (i in 0 until sentences.length()) {
            val part = sentences.optJSONArray(i)?.optString(0, "") ?: ""
            if (part.isNotEmpty() && part != "null") sb.append(part)
        }
        val t = sb.toString().trim()
        return if (t.isEmpty()) null else Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString()
    }
}

/** Gemini ile metin çevirisi (OCR'dan gelen satır). Son iki satırı bağlam olarak verir. */
class GeminiTextTranslator(private val key: String, private val model: String, private val source: String) : TextTranslator {
    private val history = ArrayList<Pair<String, String>>()

    override fun translate(text: String): String? {
        val ctx = synchronized(history) {
            if (history.isEmpty()) "" else
                "Önceki satırlar (bağlam için, çevirme):\n" + history.joinToString("\n") { it.first } + "\n\n"
        }
        val prompt = "Sen bir video oyunu altyazı çevirmenisin. Aşağıdaki diyalog satırını (kaynak dil: $source) " +
            "doğal, akıcı, günlük Türkçeye çevir. Metin ekrandan okunduğu için bariz okuma hatalarını düzelt. " +
            "Karakter adlarını çevirme. Sadece Türkçe çeviriyi yaz; açıklama, tırnak ya da etiket ekleme.\n\n" +
            ctx + "Çevrilecek satır:\n" + text
        val r = GeminiClient.generate(key, model, prompt, 1024)
        if (r.error != null) {
            TranslateStatus.lastError = r.error
            return null
        }
        val t = r.text?.trim().orEmpty()
        if (t.isEmpty()) {
            TranslateStatus.lastError = "Gemini boş yanıt verdi"
            return null
        }
        TranslateStatus.lastError = null
        synchronized(history) {
            history.add(text to t)
            while (history.size > 2) history.removeAt(0)
        }
        return t
    }
}

/** Cihaz üstünde çeviri (ML Kit). Dil modeli ilk kullanımda bir kez iner. */
class MlKitTranslator(source: String, target: String) : TextTranslator {
    private val translator: Translator? = run {
        val from = TranslateLanguage.fromLanguageTag(source)
        val to = TranslateLanguage.fromLanguageTag(target)
        if (from == null || to == null) null
        else Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(from).setTargetLanguage(to).build())
    }
    @Volatile private var modelReady = false
    @Volatile private var failedAt = 0L

    private fun prepare(): Boolean {
        val client = translator ?: return false
        if (modelReady) return true
        if (System.currentTimeMillis() - failedAt < 30000) return false
        return try {
            Tasks.await(client.downloadModelIfNeeded(DownloadConditions.Builder().build()), 40, TimeUnit.SECONDS)
            modelReady = true
            true
        } catch (e: Exception) {
            failedAt = System.currentTimeMillis()
            TranslateStatus.lastError = "Çevrimdışı model indirilemedi (internet gerekir)"
            false
        }
    }

    override fun translate(text: String): String? {
        val client = translator ?: return null
        if (!prepare()) return null
        return try {
            val r = Tasks.await(client.translate(text), 8, TimeUnit.SECONDS)
            TranslateStatus.lastError = null
            r
        } catch (e: Exception) {
            null
        }
    }

    fun close() {
        translator?.close()
    }
}

class FallbackTranslator(private val primary: TextTranslator, private val fallback: TextTranslator) : TextTranslator {
    override fun translate(text: String): String? = primary.translate(text) ?: fallback.translate(text)
}

/** Konuşmacı işaretini ("- ", ">>") çevirmene göndermez, çevirinin başına geri koyar. */
class PrefixTranslator(private val inner: TextTranslator) : TextTranslator {
    private val pattern = Regex("^(?:[-–—]+|>{1,3})\\s*")

    override fun translate(text: String): String? {
        val trimmed = text.trim()
        val m = pattern.find(trimmed) ?: return inner.translate(trimmed)
        val prefix = m.value
        val rest = trimmed.substring(prefix.length).trim()
        if (rest.isEmpty()) return prefix.trim()
        val t = inner.translate(rest)?.trim() ?: return null
        return if (t.isEmpty()) null else prefix + t
    }
}

object Translators {
    private var sig = ""
    private var cached: TextTranslator? = null
    private var offline: MlKitTranslator? = null

    @Synchronized
    fun get(ctx: Context): TextTranslator {
        val engine = Prefs.engine(ctx)
        val src = Prefs.srcLang(ctx)
        val key = Prefs.apiKey(ctx)
        val model = Prefs.model(ctx)
        val s = "$engine|$src|$key|$model"
        val c = cached
        if (c != null && s == sig) return c
        offline?.close()
        val ml = MlKitTranslator(src, "tr")
        offline = ml
        val google = GoogleGtxTranslator(src, "tr")
        val base: TextTranslator = when (engine) {
            "gemini" ->
                if (key.isBlank()) TextTranslator {
                    TranslateStatus.lastError = "Gemini API anahtarı girilmemiş"
                    null
                } else FallbackTranslator(GeminiTextTranslator(key, model, src), FallbackTranslator(google, ml))
            "offline" -> ml
            else -> FallbackTranslator(google, ml)
        }
        val t = PrefixTranslator(base)
        cached = t
        sig = s
        return t
    }

    @Synchronized
    fun close() {
        offline?.close()
        offline = null
        cached = null
        sig = ""
    }
}
