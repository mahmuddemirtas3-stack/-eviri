package com.oyuncevir.ceviri

import android.content.Context
import android.content.Intent
import com.metallic.chiaki.common.Preferences
import com.metallic.chiaki.main.MainActivity
import com.metallic.chiaki.shortcut.ConsoleShortcuts

/** Momiji'nin ana ekranına ve "son oynanan konsola otomatik bağlan" özelliğine bağlanır. */
object Ps5Launcher {
    fun consoleName(ctx: Context): String? =
        try { ConsoleShortcuts.lastPlayed(ctx)?.name } catch (e: Throwable) { null }

    /** Son konsola doğrudan bağlanır; konsol yoksa Momiji ana ekranı açılır. */
    fun playIntent(ctx: Context): Intent {
        // Ekranda oyun tuşları ve istatistik görünmesin (monitörde oynanıyor)
        try {
            val p = Preferences(ctx)
            p.onScreenControlsEnabled = false
            p.streamStatsEnabled = false
        } catch (e: Throwable) {
        }
        val c = try { ConsoleShortcuts.lastPlayed(ctx) } catch (e: Throwable) { null }
        val i = if (c != null) MainActivity.playIntent(ctx, c.mac, c.name)
        else Intent(ctx, MainActivity::class.java)
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Konsol ekleme/yönetme ekranı */
    fun manageIntent(ctx: Context): Intent =
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
