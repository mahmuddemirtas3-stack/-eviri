package com.oyuncevir.ceviri

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** Momiji'nin koyu turuncu paleti */
object Pal {
    val BG = 0xFF151312.toInt()
    val CARD = 0xFF221E1C.toInt()
    val CARD_HI = 0xFF2C2826.toInt()
    val FIELD = 0xFF373230.toInt()
    val ACCENT = 0xFFFF9166.toInt()
    val ON_ACCENT = 0xFF3D1203.toInt()
    val TONAL = 0xFF433730.toInt()
    val ON_TONAL = 0xFFFFE3C7.toInt()
    val GREEN = 0xFF9FD49B.toInt()
    val RED = 0xFFFFB4AB.toInt()
    val TEXT = 0xFFEDE0DC.toInt()
    val MUTED = 0xFFD8C2BB.toInt()
}

class UiKit(private val ctx: Context) {
    private val density = ctx.resources.displayMetrics.density

    fun dp(v: Int): Int = (v * density).toInt()

    fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, dp(top), 0, dp(bottom))
        return p
    }

    fun label(t: String, size: Float = 15f, color: Int = Pal.TEXT, bold: Boolean = false): TextView {
        val v = TextView(ctx)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    fun card(): LinearLayout {
        val c = LinearLayout(ctx)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(Pal.CARD, 24)
        c.setPadding(dp(18), dp(16), dp(18), dp(16))
        return c
    }

    /** Hap biçimli düğme */
    fun button(text: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        val v = TextView(ctx)
        v.text = text
        v.textSize = 15f
        v.setTextColor(fg)
        v.gravity = Gravity.CENTER
        v.setTypeface(v.typeface, Typeface.BOLD)
        v.background = rounded(bg, 28)
        v.setPadding(dp(18), dp(14), dp(18), dp(14))
        v.setOnClickListener { onClick() }
        return v
    }

    fun primary(text: String, onClick: () -> Unit) = button(text, Pal.ACCENT, Pal.ON_ACCENT, onClick)
    fun tonal(text: String, onClick: () -> Unit) = button(text, Pal.TONAL, Pal.ON_TONAL, onClick)

    fun field(hintText: String, initial: String, password: Boolean, onChange: (String) -> Unit): EditText {
        val e = EditText(ctx)
        e.setText(initial)
        e.setHint(hintText)
        e.setTextColor(Pal.TEXT)
        e.setHintTextColor(Pal.MUTED)
        e.textSize = 15f
        e.inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
        e.background = rounded(Pal.FIELD, 16)
        e.setPadding(dp(16), dp(12), dp(16), dp(12))
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                onChange(s?.toString() ?: "")
            }
        })
        return e
    }

    /** minV..maxV aralığında kaydırıcı */
    fun seek(minV: Int, maxV: Int, value: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(ctx)
        s.max = maxV - minV
        s.progress = (value - minV).coerceIn(0, maxV - minV)
        s.progressTintList = ColorStateList.valueOf(Pal.ACCENT)
        s.thumbTintList = ColorStateList.valueOf(Pal.ACCENT)
        s.progressBackgroundTintList = ColorStateList.valueOf(Pal.FIELD)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) onChange(progress + minV)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }
}

/** Yan yana seçenekli seçici */
class Segmented(private val ui: UiKit, ctx: Context, private val options: List<String>, private val onSelect: (Int) -> Unit) {
    val view = LinearLayout(ctx)
    private val items = ArrayList<TextView>()

    init {
        view.orientation = LinearLayout.HORIZONTAL
        view.background = ui.rounded(Pal.FIELD, 24)
        view.setPadding(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4))
        for ((i, o) in options.withIndex()) {
            val t = ui.label(o, 13f, Pal.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(ui.dp(6), ui.dp(10), ui.dp(6), ui.dp(10))
            t.setOnClickListener {
                select(i)
                onSelect(i)
            }
            items.add(t)
            view.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    fun select(index: Int) {
        for ((i, t) in items.withIndex()) {
            val on = i == index
            t.background = ui.rounded(if (on) Pal.ACCENT else Color.TRANSPARENT, 20)
            t.setTextColor(if (on) Pal.ON_ACCENT else Pal.MUTED)
        }
    }
}
