package com.oyuncevir.ceviri

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Oyunca ana menüsü (Momiji'nin görünümünde): PS5'e bağlan ve çeviri ayarları. */
class CeviriActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var consoleTitle: TextView
    private lateinit var consoleSub: TextView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = UiKit(this)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(16), ui.dp(40), ui.dp(16), ui.dp(24))
        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(
                ui.dp(16), insets.systemWindowInsetTop + ui.dp(16),
                ui.dp(16), insets.systemWindowInsetBottom + ui.dp(24)
            )
            insets
        }

        // Başlık
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.addView(ui.label("Oyunca", 30f, Pal.TEXT, true))
        head.addView(ui.label("Oyunlara anlık Türkçe altyazı", 14f, Pal.MUTED))
        root.addView(head, ui.lp(0, 18))

        // Konsol kartı
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        hero.background = ui.rounded(Pal.CARD_HI, 28)
        hero.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(20))
        consoleTitle = ui.label("", 22f, Pal.TEXT, true)
        consoleSub = ui.label("", 13f, Pal.MUTED)
        hero.addView(consoleTitle)
        hero.addView(consoleSub, ui.lp(2, 16))
        hero.addView(ui.primary("▶  Oyna") { play() }, ui.lp(0, 10))
        hero.addView(ui.tonal("Konsol ekle / yönet") { startActivity(Ps5Launcher.manageIntent(this)) })
        root.addView(hero, ui.lp(0, 14))

        // Kullanım
        val help = ui.card()
        help.addView(ui.label("Nasıl çalışır", 16f, Pal.TEXT, true), ui.lp(0, 8))
        help.addView(
            ui.label(
                "• Oyna'ya bas, PS5'e bağlanır. Yayın telefonda açılır, sen monitörde kumandayla oynarsın.\n" +
                    "• Ekranın sol kenarından sağa çek: ayarlar. Orada \"Okuma bölgesini seç\" ile altyazının çıktığı yeri çiz.\n" +
                    "• Sağ kenardan sola çek: ekranı karart. Telefon ekranı siyah olsa da okuma ve altyazı sürer.\n" +
                    "• İlk seferde \"Konsol ekle / yönet\"ten PS5'ini ekle.",
                13f, Pal.MUTED
            )
        )
        root.addView(help, ui.lp(0, 14))

        // Ayarlar
        root.addView(SettingsPanel.build(this, ui, SettingsHooks()), ui.lp(0, 0))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Pal.BG)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val n = Ps5Launcher.consoleName(this)
        consoleTitle.text = n ?: "Konsol seçilmedi"
        consoleSub.text = if (n != null) "Son oynanan konsol, otomatik bağlanır" else "Önce \"Konsol ekle / yönet\"ten PS5'ini ekle"
    }

    private fun play() {
        if (Ps5Launcher.consoleName(this) == null) {
            Toast.makeText(this, "Önce konsolunu ekle", Toast.LENGTH_LONG).show()
        }
        try {
            startActivity(Ps5Launcher.playIntent(this))
        } catch (e: Exception) {
            Toast.makeText(this, "Bağlantı ekranı açılamadı", Toast.LENGTH_LONG).show()
        }
    }
}
