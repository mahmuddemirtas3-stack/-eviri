package com.oyuncevir.ceviri

import com.oyuncevir.ceviri.core.OcrNoise
import com.oyuncevir.ceviri.core.StabilizerKind
import com.oyuncevir.ceviri.core.SubtitleStabilizer
import com.oyuncevir.ceviri.core.TextMatch
import java.util.concurrent.Executor
import kotlin.math.max
import kotlin.math.min

interface SubSink {
    fun show(text: String, stays: Boolean)
    fun clear()
    fun status(message: String)
}

/**
 * Okunan satır → gürültü temizliği → kararlılık → önbellek/çeviri → ekran.
 * Her şey ana iş parçacığında çağrılır; çeviri [exec]'te yapılır. (GameTranslator, AGPL-3.0, hattından uyarlanmıştır.)
 */
class SubPipeline(
    private val translator: () -> TextTranslator,
    private val exec: Executor,
    private val post: (Runnable) -> Unit,
    private val sink: SubSink
) {
    private val stabilizer = SubtitleStabilizer()
    private val cache = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > 300
    }
    private var latest = 0
    private var shown = 0
    private var onScreen = -1
    private var session = 0

    fun onLines(lines: List<String>) {
        val text = lines.map { OcrNoise.clean(it) }.filter { it.isNotEmpty() }.joinToString("\n")
        val a = stabilizer.feed(text)
        when (a.kind) {
            StabilizerKind.NONE -> {}
            StabilizerKind.CLEAR -> {
                onScreen = -1
                sink.clear()
            }
            StabilizerKind.TRANSLATE, StabilizerKind.RESTORE -> {
                val src = a.text ?: return
                val key = TextMatch.normalizeRows(src)
                val n = ++latest
                onScreen = n
                val hit = cache[key]
                if (hit != null) {
                    shown = n
                    sink.show(hit, true)
                    return
                }
                val current = session
                exec.execute {
                    val t = translator().translate(src)
                    post(Runnable { done(n, current, src, key, t) })
                }
            }
            else -> {}
        }
    }

    private fun done(n: Int, current: Int, src: String, key: String, t: String?) {
        if (current != session) return
        if (t == null) {
            stabilizer.forgetSent()
            sink.status(TranslateStatus.lastError ?: "Çeviri hatası")
            return
        }
        if (n < shown) return
        if (!stabilizer.shouldSend(src, t)) return
        cache[key] = t
        shown = n
        sink.show(t, n == onScreen)
    }

    fun reset() {
        session++
        onScreen = -1
        if (stabilizer.reset().kind == StabilizerKind.CLEAR) sink.clear()
    }

    companion object {
        fun readingTime(text: String): Long = min(8000, max(2000, 1200 + 60 * text.length)).toLong()
    }
}
