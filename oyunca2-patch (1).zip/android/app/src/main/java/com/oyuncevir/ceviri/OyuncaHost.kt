package com.oyuncevir.ceviri

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Yayın ekranının (StreamActivity) içinde çalışır: oyun görüntüsünü doğrudan yüzeyden okur (PixelCopy),
 * bu yüzden telefon ekranı karartılsa da okuma sürer. Altyazı, çekmeceler ve karartma burada.
 */
class OyuncaHost private constructor(private val act: Activity) : SubSink {

    companion object {
        private const val TAG = "OyuncaHost"
        @Volatile private var current: OyuncaHost? = null

        fun attach(a: Activity) {
            try {
                current?.release()
                val h = OyuncaHost(a)
                current = h
                h.start()
            } catch (e: Throwable) {
                Log.e(TAG, "attach failed", e)
            }
        }

        fun detach(a: Activity) {
            val c = current
            if (c != null && c.act === a) {
                c.release()
                current = null
            }
        }
    }

    private val ui = UiKit(act)
    private val main = Handler(Looper.getMainLooper())
    private val copyThread = HandlerThread("oyunca-copy")
    private lateinit var copyHandler: Handler
    private val exec = Executors.newFixedThreadPool(2)
    private var recognizer: TextRecognizer? = null
    private lateinit var pipeline: SubPipeline

    private lateinit var layer: FrameLayout
    private lateinit var cover: View
    private lateinit var subtitle: TextView
    private lateinit var frameView: FrameOverlay
    private lateinit var selectView: SelectView
    private lateinit var leftScrim: View
    private lateinit var leftPanel: ScrollView
    private lateinit var rightScrim: View
    private lateinit var rightPanel: android.widget.LinearLayout

    @Volatile private var video: SurfaceView? = null
    @Volatile private var alive = false
    @Volatile private var translating = false
    @Volatile private var hasRegion = false
    private var rl = 0f
    private var rt = 0f
    private var rr = 0f
    private var rb = 0f
    private var covered = false
    private var coverBeforeSelect = false
    private var leftOpen = false
    private var rightOpen = false

    private var frameBmp: Bitmap? = null
    private var lastSig: IntArray? = null
    private var lastLines: List<String> = emptyList()

    private val hideSubtitle = Runnable { subtitle.visibility = View.GONE }

    // ------------------------------------------------------------------ kurulum

    private fun start() {
        alive = true
        copyThread.start()
        copyHandler = Handler(copyThread.looper)
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        pipeline = SubPipeline({ Translators.get(act) }, exec, { r -> main.post(r) }, this)

        buildViews()
        if (Prefs.hasRegion(act)) {
            val r = Prefs.region(act)
            rl = r[0]; rt = r[1]; rr = r[2]; rb = r[3]
            hasRegion = true
            translating = true
        } else {
            showSubtitle("Başlamak için ekranın sol kenarından sağa çek, \"Okuma bölgesini seç\"e bas", false)
        }
        refreshVideo()
        copyHandler.postDelayed({ tick() }, 1500)
    }

    fun release() {
        alive = false
        main.removeCallbacksAndMessages(null)
        try {
            setCover(false)
            (layer.parent as? ViewGroup)?.removeView(layer)
        } catch (e: Throwable) {
        }
        copyHandler.removeCallbacksAndMessages(null)
        copyThread.quitSafely()
        exec.shutdownNow()
        try { recognizer?.close() } catch (e: Throwable) {}
        Translators.close()
        frameBmp = null
    }

    private fun buildViews() {
        layer = FrameLayout(act)

        cover = View(act)
        cover.setBackgroundColor(Color.BLACK)
        cover.visibility = View.GONE
        layer.addView(cover, FrameLayout.LayoutParams(-1, -1))

        subtitle = TextView(act)
        subtitle.visibility = View.GONE
        layer.addView(subtitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        frameView = FrameOverlay(act)
        frameView.visibility = View.GONE
        layer.addView(frameView, FrameLayout.LayoutParams(-1, -1))

        selectView = SelectView(act) { l, t, r, b -> finishSelect(l, t, r, b) }
        selectView.visibility = View.GONE
        layer.addView(selectView, FrameLayout.LayoutParams(-1, -1))

        // Kenar tutamaçları
        val hl = EdgeHandle(act, true) { openLeft() }
        layer.addView(hl, FrameLayout.LayoutParams(ui.dp(48), ui.dp(220), Gravity.START or Gravity.CENTER_VERTICAL))
        val hr = EdgeHandle(act, false) { openRight() }
        layer.addView(hr, FrameLayout.LayoutParams(ui.dp(48), ui.dp(220), Gravity.END or Gravity.CENTER_VERTICAL))

        // Sol çekmece: ayarlar
        leftScrim = View(act)
        leftScrim.setBackgroundColor(0x66000000)
        leftScrim.visibility = View.GONE
        leftScrim.setOnClickListener { closeLeft() }
        layer.addView(leftScrim, FrameLayout.LayoutParams(-1, -1))

        val hooks = SettingsHooks(
            onStyle = { placeSubtitle() },
            onEngine = { pipeline.reset() },
            onPickRegion = { closeLeft(); startSelecting() },
            onToggleCover = { toggleCover() },
            onTogglePause = { togglePause() }
        )
        val content = SettingsPanel.build(act, ui, hooks)
        content.setPadding(ui.dp(12), ui.dp(40), ui.dp(12), ui.dp(24))
        leftPanel = ScrollView(act)
        leftPanel.setBackgroundColor(Pal.BG)
        leftPanel.addView(content)
        leftPanel.visibility = View.GONE
        layer.addView(leftPanel, FrameLayout.LayoutParams(ui.dp(340), -1, Gravity.START))

        // Sağ çekmece: hızlı işlemler
        rightScrim = View(act)
        rightScrim.setBackgroundColor(0x33000000)
        rightScrim.visibility = View.GONE
        rightScrim.setOnClickListener { closeRight() }
        layer.addView(rightScrim, FrameLayout.LayoutParams(-1, -1))

        rightPanel = android.widget.LinearLayout(act)
        rightPanel.orientation = android.widget.LinearLayout.VERTICAL
        rightPanel.background = ui.rounded(Pal.BG, 24)
        rightPanel.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14))
        rightPanel.addView(ui.label("Hızlı işlemler", 15f, Pal.TEXT, true), ui.lp(0, 10))
        rightPanel.addView(ui.tonal("Ekranı karart / aç") { closeRight(); toggleCover() }, ui.lp(0, 8))
        rightPanel.addView(ui.tonal("Bölge seç") { closeRight(); startSelecting() }, ui.lp(0, 8))
        rightPanel.addView(ui.tonal("Duraklat / sürdür") { closeRight(); togglePause() }, ui.lp(0, 8))
        rightPanel.addView(ui.primary("Ayarlar") { closeRight(); openLeft() })
        rightPanel.visibility = View.GONE
        layer.addView(rightPanel, FrameLayout.LayoutParams(ui.dp(240), -2, Gravity.END or Gravity.CENTER_VERTICAL))

        act.addContentView(layer, ViewGroup.LayoutParams(-1, -1))
        layer.post { placeSubtitle() }
    }

    // ------------------------------------------------------------------ çekmeceler

    private fun openLeft() {
        if (leftOpen) return
        leftOpen = true
        leftScrim.visibility = View.VISIBLE
        leftPanel.visibility = View.VISIBLE
        leftPanel.translationX = -ui.dp(340).toFloat()
        leftPanel.animate().translationX(0f).setDuration(180).start()
        frameView.visibility = View.VISIBLE
        frameView.invalidate()
    }

    private fun closeLeft() {
        if (!leftOpen) return
        leftOpen = false
        leftScrim.visibility = View.GONE
        leftPanel.animate().translationX(-ui.dp(340).toFloat()).setDuration(150)
            .withEndAction { if (!leftOpen) leftPanel.visibility = View.GONE }.start()
        if (!selectView.isShown) frameView.visibility = View.GONE
    }

    private fun openRight() {
        if (rightOpen) return
        rightOpen = true
        rightScrim.visibility = View.VISIBLE
        rightPanel.visibility = View.VISIBLE
    }

    private fun closeRight() {
        rightOpen = false
        rightScrim.visibility = View.GONE
        rightPanel.visibility = View.GONE
    }

    // ------------------------------------------------------------------ karartma ve duraklatma

    private fun toggleCover() = setCover(!covered)

    private fun setCover(on: Boolean) {
        covered = on
        // Sadece oyun görüntüsü kapanır; ekran parlaklığına dokunulmaz, altyazı olduğu gibi kalır
        cover.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun togglePause() {
        if (!hasRegion) {
            showSubtitle("Önce okuma bölgesini seç", false)
            return
        }
        translating = !translating
        if (!translating) subtitle.visibility = View.GONE else pipeline.reset()
        showSubtitle(if (translating) "Çeviri sürüyor" else "Çeviri duraklatıldı", false)
    }

    // ------------------------------------------------------------------ bölge seçme

    private fun startSelecting() {
        coverBeforeSelect = covered
        if (covered) setCover(false)
        selectView.visibility = View.VISIBLE
        frameView.visibility = View.GONE
    }

    private fun finishSelect(l: Float, t: Float, r: Float, b: Float) {
        selectView.visibility = View.GONE
        val vr = videoRect()
        if (l < 0 || vr == null || vr.width() < 2 || vr.height() < 2) {
            if (coverBeforeSelect) setCover(true)
            return
        }
        val fl = ((l - vr.left) / vr.width()).coerceIn(0f, 1f)
        val fr = ((r - vr.left) / vr.width()).coerceIn(0f, 1f)
        val ft = ((t - vr.top) / vr.height()).coerceIn(0f, 1f)
        val fb = ((b - vr.top) / vr.height()).coerceIn(0f, 1f)
        if (fr - fl < 0.02f || fb - ft < 0.01f) {
            showSubtitle("Bölge çok küçük, tekrar dene", false)
            if (coverBeforeSelect) setCover(true)
            return
        }
        rl = fl; rt = ft; rr = fr; rb = fb
        Prefs.saveRegion(act, rl, rt, rr, rb)
        hasRegion = true
        translating = true
        lastSig = null
        pipeline.reset()
        frameView.visibility = View.VISIBLE
        frameView.invalidate()
        main.postDelayed({ if (!leftOpen) frameView.visibility = View.GONE }, 1800)
        showSubtitle("Bölge kaydedildi. Çeviri başladı", false)
        if (coverBeforeSelect) main.postDelayed({ setCover(true) }, 1200)
    }

    // ------------------------------------------------------------------ video yüzeyi

    private fun findSurface(v: View): SurfaceView? {
        if (v is SurfaceView && v.isShown && v.width > 0 && v.height > 0) return v
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                val r = findSurface(v.getChildAt(i))
                if (r != null) return r
            }
        }
        return null
    }

    private fun refreshVideo() {
        if (!alive) return
        video = findSurface(act.window.decorView)
        main.postDelayed({ refreshVideo() }, 1000)
    }

    /** Oyun görüntüsünün katman içindeki dikdörtgeni */
    private fun videoRect(): RectF? {
        val sv = video ?: findSurface(act.window.decorView) ?: return null
        val a = IntArray(2)
        val b = IntArray(2)
        sv.getLocationOnScreen(a)
        layer.getLocationOnScreen(b)
        val x = (a[0] - b[0]).toFloat()
        val y = (a[1] - b[1]).toFloat()
        return RectF(x, y, x + sv.width, y + sv.height)
    }

    // ------------------------------------------------------------------ okuma döngüsü

    private fun interval(): Long = when (Prefs.speed(act)) {
        0 -> 150L
        1 -> 260L
        else -> 500L
    }

    private fun next(delay: Long = interval()) {
        if (alive) copyHandler.postDelayed({ tick() }, delay)
    }

    private fun tick() {
        if (!alive) return
        val sv = video
        if (!translating || !hasRegion || sv == null || sv.width < 2 || sv.height < 2) {
            next(500)
            return
        }
        try {
            if (!sv.holder.surface.isValid) {
                next(400)
                return
            }
            val dw = 1280
            val dh = (dw.toFloat() * sv.height / sv.width).toInt().coerceIn(2, 2600)
            var bmp = frameBmp
            if (bmp == null || bmp.width != dw || bmp.height != dh) {
                bmp = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                frameBmp = bmp
            }
            val target = bmp
            PixelCopy.request(sv, target, { result ->
                if (result == PixelCopy.SUCCESS) onFrame(target) else next(300)
            }, copyHandler)
        } catch (e: Throwable) {
            Log.w(TAG, "copy failed", e)
            next(600)
        }
    }

    private fun onFrame(frame: Bitmap) {
        try {
            val x = (rl * frame.width).toInt().coerceIn(0, frame.width - 2)
            val y = (rt * frame.height).toInt().coerceIn(0, frame.height - 2)
            val w = ((rr - rl) * frame.width).toInt().coerceIn(2, frame.width - x)
            val h = ((rb - rt) * frame.height).toInt().coerceIn(2, frame.height - y)
            val crop = Bitmap.createBitmap(frame, x, y, w, h)
            val sig = signature(crop)
            val prev = lastSig
            if (prev != null && sigDiff(prev, sig) <= 3) {
                // Görüntü değişmedi: yeniden okuma yok, önceki okuma tekrar beslenir
                crop.recycle()
                val lines = lastLines
                main.post { if (alive && translating) pipeline.onLines(lines) }
                next()
                return
            }
            lastSig = sig
            val rec = recognizer
            if (rec == null) {
                crop.recycle()
                next()
                return
            }
            rec.process(InputImage.fromBitmap(crop, 0))
                .addOnSuccessListener { vt ->
                    val lines = vt.textBlocks.flatMap { b -> b.lines }.map { it.text }
                    lastLines = lines
                    if (alive && translating) pipeline.onLines(lines)
                }
                .addOnFailureListener { }
                .addOnCompleteListener {
                    crop.recycle()
                    next()
                }
        } catch (e: Throwable) {
            Log.w(TAG, "frame failed", e)
            next(600)
        }
    }

    private fun signature(src: Bitmap): IntArray {
        val sw = 48
        val sh = 16
        val s = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        s.getPixels(px, 0, sw, 0, 0, sw, sh)
        if (s !== src) s.recycle()
        val out = IntArray(px.size)
        for (i in px.indices) {
            val c = px[i]
            out[i] = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
        }
        return out
    }

    private fun sigDiff(a: IntArray, b: IntArray): Int {
        if (a.size != b.size) return 999
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return (sum / a.size).toInt()
    }

    // ------------------------------------------------------------------ altyazı (SubSink)

    override fun show(text: String, stays: Boolean) = showSubtitle(text, stays)

    override fun clear() {
        main.post { subtitle.visibility = View.GONE }
    }

    override fun status(message: String) = showSubtitle(message, false)

    private fun showSubtitle(text: String, stays: Boolean) {
        if (!alive) return
        main.removeCallbacks(hideSubtitle)
        subtitle.text = text
        SubtitleStyle.apply(act, subtitle, ui)
        subtitle.visibility = View.VISIBLE
        placeSubtitle()
        if (!stays) main.postDelayed(hideSubtitle, SubPipeline.readingTime(text))
    }

    private fun placeSubtitle() {
        val w = layer.width
        val h = layer.height
        if (w <= 0 || h <= 0) return
        SubtitleStyle.apply(act, subtitle, ui)
        subtitle.maxWidth = (w * 0.9f).toInt()
        subtitle.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.AT_MOST)
        )
        val lp = subtitle.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.topMargin = ((h - subtitle.measuredHeight) * Prefs.subPos(act) / 100f).toInt().coerceAtLeast(0)
        subtitle.layoutParams = lp
    }

    // ------------------------------------------------------------------ görünümler

    /** Kenardan çekince ya da dokununca çekmeceyi açan tutamaç */
    private inner class EdgeHandle(ctx: Context, private val isLeft: Boolean, private val onOpen: () -> Unit) : View(ctx) {
        private var downX = 0f
        private var fired = false
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x55FFFFFF }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (Build.VERSION.SDK_INT >= 29) setSystemGestureExclusionRects(listOf(Rect(0, 0, w, h)))
        }

        override fun onDraw(c: Canvas) {
            val tw = ui.dp(5).toFloat()
            val th = ui.dp(56).toFloat()
            val cy = height / 2f
            val x0 = if (isLeft) 0f else width - tw
            c.drawRoundRect(x0, cy - th / 2, x0 + tw, cy + th / 2, tw, tw, paint)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x
                    fired = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.x - downX) * (if (isLeft) 1 else -1)
                    if (!fired && dx > ui.dp(30)) {
                        fired = true
                        onOpen()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!fired && abs(e.x - downX) < ui.dp(10)) onOpen()
                }
            }
            return true
        }
    }

    /** Seçili okuma bölgesinin çerçevesi */
    private inner class FrameOverlay(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Pal.GREEN
            style = Paint.Style.STROKE
            strokeWidth = ui.dp(2).toFloat()
        }

        override fun onDraw(c: Canvas) {
            if (!hasRegion) return
            val vr = videoRect() ?: return
            c.drawRect(
                vr.left + rl * vr.width(), vr.top + rt * vr.height(),
                vr.left + rr * vr.width(), vr.top + rb * vr.height(), paint
            )
        }
    }

    /** Parmakla dikdörtgen çizdirir; koordinatlar katmana göre döner */
    private inner class SelectView(ctx: Context, private val onDone: (Float, Float, Float, Float) -> Unit) : View(ctx) {
        private var sx = 0f
        private var sy = 0f
        private var ex = 0f
        private var ey = 0f
        private var drawing = false
        private val rectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Pal.ACCENT
            style = Paint.Style.STROKE
            strokeWidth = ui.dp(3).toFloat()
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = ui.dp(18).toFloat()
            textAlign = Paint.Align.CENTER
            setShadowLayer(6f, 0f, 2f, Color.BLACK)
        }

        init {
            setBackgroundColor(0x55000000)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.x; sy = e.y; ex = sx; ey = sy; drawing = true
                }
                MotionEvent.ACTION_MOVE -> {
                    ex = e.x; ey = e.y
                }
                MotionEvent.ACTION_UP -> {
                    ex = e.x; ey = e.y; drawing = false
                    val l = minOf(sx, ex)
                    val t = minOf(sy, ey)
                    val r = maxOf(sx, ex)
                    val b = maxOf(sy, ey)
                    if (r - l > ui.dp(30) && b - t > ui.dp(10)) onDone(l, t, r, b) else onDone(-1f, -1f, -1f, -1f)
                    return true
                }
            }
            invalidate()
            return true
        }

        override fun onDraw(c: Canvas) {
            if (!drawing) {
                c.drawText("Çevrilecek altyazının üstünü parmağınla çiz", width / 2f, height / 2f, textPaint)
            } else {
                c.drawRect(minOf(sx, ex), minOf(sy, ey), maxOf(sx, ex), maxOf(sy, ey), rectPaint)
            }
        }
    }
}
