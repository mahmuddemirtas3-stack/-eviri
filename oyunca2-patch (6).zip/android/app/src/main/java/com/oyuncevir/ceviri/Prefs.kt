package com.oyuncevir.ceviri

import android.content.Context

object Prefs {
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    const val DEFAULT_CLAUDE_MODEL = "claude-haiku-5-5"
    const val DEFAULT_TTS_MODEL = "gemini-3.1-flash-tts-preview"

    private fun sp(c: Context) = c.getSharedPreferences("oyunca", Context.MODE_PRIVATE)

    // offline | google | deepl | gemini | claude
    fun engine(c: Context): String = sp(c).getString("engine2", "google") ?: "google"
    fun setEngine(c: Context, v: String) { sp(c).edit().putString("engine2", v).apply() }

    fun apiKey(c: Context): String = (sp(c).getString("key", "") ?: "").ifBlank { EmbeddedKeys.GEMINI }
    fun setApiKey(c: Context, v: String) { sp(c).edit().putString("key", v.trim()).apply() }

    fun model(c: Context): String {
        val m = (sp(c).getString("model", "") ?: "").trim()
        return if (m.isEmpty()) DEFAULT_MODEL else m
    }
    fun setModel(c: Context, v: String) { sp(c).edit().putString("model", v.trim()).apply() }

    fun deeplKey(c: Context): String = (sp(c).getString("deeplkey", "") ?: "").ifBlank { EmbeddedKeys.DEEPL }
    fun setDeeplKey(c: Context, v: String) { sp(c).edit().putString("deeplkey", v.trim()).apply() }

    fun claudeKey(c: Context): String = (sp(c).getString("claudekey", "") ?: "").ifBlank { EmbeddedKeys.CLAUDE }
    fun setClaudeKey(c: Context, v: String) { sp(c).edit().putString("claudekey", v.trim()).apply() }

    fun claudeModel(c: Context): String {
        val m = (sp(c).getString("claudemodel", "") ?: "").trim()
        return if (m.isEmpty()) DEFAULT_CLAUDE_MODEL else m
    }
    fun setClaudeModel(c: Context, v: String) { sp(c).edit().putString("claudemodel", v.trim()).apply() }

    fun srcLang(c: Context): String = sp(c).getString("lang", "en") ?: "en"
    fun setSrcLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply() }

    // Altyazı görünümü
    fun textSize(c: Context): Int = sp(c).getInt("tsize", 22)
    fun setTextSize(c: Context, v: Int) { sp(c).edit().putInt("tsize", v.coerceIn(12, 64)).apply() }

    /** 0 = en üst, 100 = en alt */
    fun subPos(c: Context): Int = sp(c).getInt("subpos", 86)
    fun setSubPos(c: Context, v: Int) { sp(c).edit().putInt("subpos", v.coerceIn(0, 100)).apply() }

    /** Altyazı kutusunun yatay merkezi, ekran genişliğinin yüzdesi */
    fun subX(c: Context): Int = sp(c).getInt("subx", 50)
    fun setSubX(c: Context, v: Int) { sp(c).edit().putInt("subx", v.coerceIn(0, 100)).apply() }

    fun subBg(c: Context): Int = sp(c).getInt("subbg", 80)
    fun setSubBg(c: Context, v: Int) { sp(c).edit().putInt("subbg", v.coerceIn(0, 100)).apply() }

    fun font(c: Context): Int = sp(c).getInt("font", 0)
    fun setFont(c: Context, v: Int) { sp(c).edit().putInt("font", v).apply() }

    fun bold(c: Context): Boolean = sp(c).getBoolean("bold", true)
    fun setBold(c: Context, v: Boolean) { sp(c).edit().putBoolean("bold", v).apply() }

    fun color(c: Context): Int = sp(c).getInt("color", 0)
    fun setColor(c: Context, v: Int) { sp(c).edit().putInt("color", v).apply() }

    /** 0 hızlı, 1 dengeli, 2 tasarruf */
    fun speed(c: Context): Int = sp(c).getInt("speed", 0)
    fun setSpeed(c: Context, v: Int) { sp(c).edit().putInt("speed", v).apply() }

    // Okuma bölgesi: oyun görüntüsüne oranla (0..1)
    fun hasRegion(c: Context): Boolean = sp(c).getBoolean("vhas", false)
    fun region(c: Context): FloatArray {
        val p = sp(c)
        return floatArrayOf(p.getFloat("vl", 0f), p.getFloat("vt", 0f), p.getFloat("vr", 0f), p.getFloat("vb", 0f))
    }
    fun saveRegion(c: Context, l: Float, t: Float, r: Float, b: Float) {
        sp(c).edit().putFloat("vl", l).putFloat("vt", t).putFloat("vr", r).putFloat("vb", b)
            .putBoolean("vhas", true).apply()
    }

    // Seslendirme
    fun dubOn(c: Context): Boolean = sp(c).getBoolean("dubon", false)
    fun setDubOn(c: Context, v: Boolean) { sp(c).edit().putBoolean("dubon", v).apply() }

    /** system | gemini */
    fun dubEngine(c: Context): String = sp(c).getString("dubengine", "system") ?: "system"
    fun setDubEngine(c: Context, v: String) { sp(c).edit().putString("dubengine", v).apply() }

    fun dubVoice(c: Context): String = sp(c).getString("dubvoice", "Kore") ?: "Kore"
    fun setDubVoice(c: Context, v: String) { sp(c).edit().putString("dubvoice", v).apply() }

    fun dubModel(c: Context): String {
        val m = (sp(c).getString("dubmodel", "") ?: "").trim()
        return if (m.isEmpty()) DEFAULT_TTS_MODEL else m
    }
    fun setDubModel(c: Context, v: String) { sp(c).edit().putString("dubmodel", v.trim()).apply() }

    /** Telefon sesi konuşma hızı, 10 = 1.0x */
    fun dubRate(c: Context): Int = sp(c).getInt("dubrate", 10)
    fun setDubRate(c: Context, v: Int) { sp(c).edit().putInt("dubrate", v.coerceIn(6, 20)).apply() }
}
