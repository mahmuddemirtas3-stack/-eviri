package com.oyuncevir.ceviri

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.Executors

/** Türkçe altyazıyı sesli okur: telefonun Türkçe sesi ya da Gemini TTS. */
class Dubber private constructor(private val app: Context) {

    companion object {
        @Volatile private var inst: Dubber? = null

        fun get(ctx: Context): Dubber =
            inst ?: synchronized(this) { inst ?: Dubber(ctx.applicationContext).also { inst = it } }
    }

    @Volatile var listener: ((String) -> Unit)? = null

    private val exec = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsBroken = false
    @Volatile private var pending: String? = null
    private var track: AudioTrack? = null
    private val trackLock = Any()
    @Volatile private var gen = 0
    @Volatile private var warnedNoKey = false
    private val cache = object : LinkedHashMap<String, Pair<ByteArray, Int>>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<ByteArray, Int>>?) = size > 40
    }

    fun speak(text: String) {
        val t = text.replace("\n", " ").trim()
        if (t.isEmpty()) return
        stop()
        val my = ++gen
        if (Prefs.dubEngine(app) == "gemini") speakGemini(t, my) else speakSystem(t)
    }

    fun stop() {
        gen++
        pending = null
        synchronized(trackLock) {
            try {
                track?.stop()
                track?.release()
            } catch (e: Exception) {
            }
            track = null
        }
        try { tts?.stop() } catch (e: Exception) {}
    }

    // ---- Telefon sesi ----

    private fun speakSystem(t: String) {
        if (ttsBroken) return
        val engine = tts
        if (engine == null) {
            pending = t
            tts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("tr", "TR"))
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    if (!ttsReady) {
                        ttsBroken = true
                        listener?.invoke("Telefonda Türkçe ses yok. Ayarlar > Dil > Metinden sese bölümünden Türkçe sesi indir")
                    } else {
                        val p = pending
                        pending = null
                        if (p != null) speakSystem(p)
                    }
                } else {
                    ttsBroken = true
                    listener?.invoke("Telefonun ses motoru başlatılamadı")
                }
            }
            return
        }
        if (!ttsReady) {
            pending = t
            return
        }
        engine.setSpeechRate(Prefs.dubRate(app) / 10f)
        engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "oyunca")
    }

    // ---- Gemini sesi ----

    private fun speakGemini(t: String, my: Int) {
        val key = Prefs.apiKey(app)
        if (key.isBlank()) {
            if (!warnedNoKey) {
                warnedNoKey = true
                listener?.invoke("Gemini sesi için API anahtarı gerekli, telefon sesi kullanılıyor")
            }
            speakSystem(t)
            return
        }
        val voice = Prefs.dubVoice(app)
        val model = Prefs.dubModel(app)
        exec.execute {
            if (my != gen) return@execute
            val ck = voice + "|" + t
            val cached = synchronized(cache) { cache[ck] }
            val audio: Pair<ByteArray, Int>
            if (cached != null) {
                audio = cached
            } else {
                val r = GeminiClient.speech(key, model, voice, t)
                val pcm = r.pcm
                if (pcm == null) {
                    if (my == gen) {
                        listener?.invoke(r.error ?: "Gemini sesi alınamadı")
                        speakSystem(t)
                    }
                    return@execute
                }
                audio = Pair(pcm, r.rate)
                synchronized(cache) { cache[ck] = audio }
            }
            if (my == gen) playPcm(audio.first, audio.second)
        }
    }

    private fun playPcm(pcm: ByteArray, rate: Int) {
        synchronized(trackLock) {
            try {
                track?.stop()
                track?.release()
            } catch (e: Exception) {
            }
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val at = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(min, pcm.size))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            at.write(pcm, 0, pcm.size)
            at.play()
            track = at
        }
    }
}
