package com.oyuncevir.ceviri

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class SettingsHooks(
    val onStyle: () -> Unit = {},
    val onEngine: () -> Unit = {},
    val onPickRegion: (() -> Unit)? = null,
    val onToggleCover: (() -> Unit)? = null,
    val onTogglePause: (() -> Unit)? = null,
    val onEditSubtitle: (() -> Unit)? = null
)

object SubtitleStyle {
    /** Gösterilen ad ve APK'ya gömülü dosya öneki (assets/fonts/<önek>_r / _b). Boş önek: telefonun yazı tipi. */
    val fontNames = arrayOf("Sistem", "Inter (modern)", "DejaVu Sans (geniş)", "DejaVu Dar", "Carlito (yumuşak)", "DejaVu Serif (tırnaklı)", "Caladea (klasik)", "Daktilo (sabit genişlik)")
    private val fontFiles = arrayOf("", "inter", "dvsans", "dvcond", "carlito", "dvserif", "caladea", "dvmono")
    private val fontExt = arrayOf("", "otf", "ttf", "ttf", "ttf", "ttf", "ttf", "ttf")
    val colors = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFE066.toInt(), 0xFF7FE3FF.toInt(), 0xFF9FD49B.toInt())

    private val cache = HashMap<String, Typeface>()

    fun typeface(ctx: Context, index: Int, bold: Boolean): Typeface {
        val i = index.coerceIn(0, fontFiles.size - 1)
        if (fontFiles[i].isEmpty()) {
            return Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val path = "fonts/" + fontFiles[i] + (if (bold) "_b." else "_r.") + fontExt[i]
        synchronized(cache) {
            cache[path]?.let { return it }
            val tf = try {
                Typeface.createFromAsset(ctx.assets, path)
            } catch (e: Exception) {
                Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            }
            cache[path] = tf
            return tf
        }
    }

    fun apply(ctx: Context, tv: TextView, ui: UiKit) {
        tv.textSize = Prefs.textSize(ctx).toFloat()
        tv.setTextColor(colors[Prefs.color(ctx).coerceIn(0, colors.size - 1)])
        tv.typeface = typeface(ctx, Prefs.font(ctx), Prefs.bold(ctx))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(Prefs.subBg(ctx) * 255 / 100, 0, 0, 0))
        bg.cornerRadius = ui.dp(10).toFloat()
        tv.background = bg
        tv.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8))
        tv.setShadowLayer(4f, 0f, 2f, 0xFF000000.toInt())
        tv.gravity = Gravity.CENTER
    }
}

object SettingsPanel {
    private val langNames = arrayOf("İngilizce", "Almanca", "Fransızca", "İspanyolca", "İtalyanca", "Portekizce")
    private val langCodes = arrayOf("en", "de", "fr", "es", "it", "pt")
    private val engines = arrayOf("offline", "google", "deepl", "gemini", "claude")
    private val engineNames = arrayOf(
        "Çevrimdışı (internetsiz)", "Google (ücretsiz, hızlı)", "DeepL (çok doğal)",
        "Gemini (yapay zekâ)", "Claude (yapay zekâ)"
    )

    fun build(ctx: Context, ui: UiKit, hooks: SettingsHooks): LinearLayout {
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL

        // ---- Çeviri motoru ----
        val eng = ui.card()
        eng.addView(ui.label("Çeviri motoru", 16f, Pal.TEXT, true), ui.lp(0, 10))
        val engineBtn = ui.tonal("") {}
        val desc = ui.label("", 12f, Pal.MUTED)
        val geminiBox = LinearLayout(ctx)
        geminiBox.orientation = LinearLayout.VERTICAL
        val deeplBox = LinearLayout(ctx)
        deeplBox.orientation = LinearLayout.VERTICAL
        val claudeBox = LinearLayout(ctx)
        claudeBox.orientation = LinearLayout.VERTICAL
        val langRow = LinearLayout(ctx)
        langRow.orientation = LinearLayout.VERTICAL

        fun refreshEngine() {
            val e = Prefs.engine(ctx)
            engineBtn.text = engineNames[engines.indexOf(e).let { if (it < 0) 1 else it }] + "  ▾"
            geminiBox.visibility = if (e == "gemini") View.VISIBLE else View.GONE
            deeplBox.visibility = if (e == "deepl") View.VISIBLE else View.GONE
            claudeBox.visibility = if (e == "claude") View.VISIBLE else View.GONE
            desc.text = when (e) {
                "offline" -> "İnternetsiz çalışır, ilk seferde dil modeli iner. Sadece Latin harfli diller."
                "deepl" -> "Çeviri kalitesiyle bilinir, çok doğal ve hızlı. Ücretsiz plan için API anahtarı gerekir."
                "gemini" -> "Bağlamı anlayan yapay zekâ. Kendi API anahtarın gerekir."
                "claude" -> "Bağlamı çok iyi anlayan yapay zekâ. Ücretli API anahtarı gerekir. Haiku modeli en hızlısıdır."
                else -> "Ücretsiz ve hızlı, internet gerekir."
            } + if (e == "offline" || e == "google") "" else " Hata olursa Google'a, sonra çevrimdışına geçer."
        }

        engineBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Çeviri motoru").setItems(engineNames) { _, which ->
                Prefs.setEngine(ctx, engines[which])
                refreshEngine()
                hooks.onEngine()
            }.show()
        }
        eng.addView(engineBtn, ui.lp(0, 8))
        eng.addView(desc, ui.lp(0, 10))

        fun openUrl(u: String) {
            ctx.startActivity(
                android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(u))
                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }

        if (EmbeddedKeys.GEMINI.isNotEmpty()) geminiBox.addView(ui.label("Anahtar uygulamaya gömülü, girmene gerek yok.", 12f, Pal.GREEN), ui.lp(0, 6))
        geminiBox.addView(ui.label("Gemini API anahtarı", 12f, Pal.MUTED), ui.lp(0, 4))
        geminiBox.addView(ui.field("AIza...", Prefs.apiKey(ctx), true) { Prefs.setApiKey(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        geminiBox.addView(ui.label("Model", 12f, Pal.MUTED), ui.lp(0, 4))
        geminiBox.addView(ui.field(Prefs.DEFAULT_MODEL, Prefs.model(ctx), false) { Prefs.setModel(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        geminiBox.addView(ui.tonal("Ücretsiz anahtar al") { openUrl("https://aistudio.google.com/apikey") }, ui.lp(0, 10))
        eng.addView(geminiBox)

        if (EmbeddedKeys.DEEPL.isNotEmpty()) deeplBox.addView(ui.label("Anahtar uygulamaya gömülü, girmene gerek yok.", 12f, Pal.GREEN), ui.lp(0, 6))
        deeplBox.addView(ui.label("DeepL API anahtarı", 12f, Pal.MUTED), ui.lp(0, 4))
        deeplBox.addView(ui.field("xxxxxxxx-...:fx", Prefs.deeplKey(ctx), true) { Prefs.setDeeplKey(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        deeplBox.addView(ui.tonal("DeepL anahtarı al") { openUrl("https://www.deepl.com/pro-api") }, ui.lp(0, 10))
        eng.addView(deeplBox)

        if (EmbeddedKeys.CLAUDE.isNotEmpty()) claudeBox.addView(ui.label("Anahtar uygulamaya gömülü, girmene gerek yok.", 12f, Pal.GREEN), ui.lp(0, 6))
        claudeBox.addView(ui.label("Claude API anahtarı", 12f, Pal.MUTED), ui.lp(0, 4))
        claudeBox.addView(ui.field("sk-ant-...", Prefs.claudeKey(ctx), true) { Prefs.setClaudeKey(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        claudeBox.addView(ui.label("Model", 12f, Pal.MUTED), ui.lp(0, 4))
        claudeBox.addView(ui.field(Prefs.DEFAULT_CLAUDE_MODEL, Prefs.claudeModel(ctx), false) { Prefs.setClaudeModel(ctx, it); hooks.onEngine() }, ui.lp(0, 8))
        claudeBox.addView(ui.tonal("Claude anahtarı al") { openUrl("https://console.anthropic.com/settings/keys") }, ui.lp(0, 10))
        eng.addView(claudeBox)

        langRow.addView(ui.label("Oyunun dili", 12f, Pal.MUTED), ui.lp(0, 4))
        val langBtn = ui.tonal("") {}
        fun langText() {
            val idx = langCodes.indexOf(Prefs.srcLang(ctx)).let { if (it < 0) 0 else it }
            langBtn.text = langNames[idx] + "  ▾"
        }
        langBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Oyunun dili").setItems(langNames) { _, which ->
                Prefs.setSrcLang(ctx, langCodes[which])
                langText()
                hooks.onEngine()
            }.show()
        }
        langText()
        langRow.addView(langBtn)
        eng.addView(langRow)
        refreshEngine()
        root.addView(eng, ui.lp(0, 12))

        // ---- Altyazı görünümü ----
        val sub = ui.card()
        sub.addView(ui.label("Altyazı", 16f, Pal.TEXT, true), ui.lp(0, 10))
        val preview = TextView(ctx)
        preview.text = "Örnek altyazı: Buradan çıkmalıyız!"
        val pv = LinearLayout(ctx)
        pv.gravity = Gravity.CENTER
        pv.background = ui.rounded(0xFF3B4A52.toInt(), 14)
        pv.setPadding(ui.dp(10), ui.dp(16), ui.dp(10), ui.dp(16))
        pv.addView(preview)
        sub.addView(pv, ui.lp(0, 12))

        fun restyle() {
            SubtitleStyle.apply(ctx, preview, ui)
            hooks.onStyle()
        }

        val sizeLabel = ui.label("", 13f, Pal.MUTED)
        sub.addView(sizeLabel, ui.lp(0, 2))
        sub.addView(ui.seek(12, 64, Prefs.textSize(ctx)) {
            Prefs.setTextSize(ctx, it)
            sizeLabel.text = "Boyut: $it"
            restyle()
        }, ui.lp(0, 8))
        sizeLabel.text = "Boyut: ${Prefs.textSize(ctx)}"

        sub.addView(ui.label("Konum (yukarı ↔ aşağı)", 13f, Pal.MUTED), ui.lp(0, 2))
        sub.addView(ui.seek(0, 100, Prefs.subPos(ctx)) {
            Prefs.setSubPos(ctx, it)
            hooks.onStyle()
        }, ui.lp(0, 8))

        sub.addView(ui.label("Arka plan koyuluğu", 13f, Pal.MUTED), ui.lp(0, 2))
        sub.addView(ui.seek(0, 100, Prefs.subBg(ctx)) {
            Prefs.setSubBg(ctx, it)
            restyle()
        }, ui.lp(0, 10))

        sub.addView(ui.label("Yazı tipi", 13f, Pal.MUTED), ui.lp(0, 4))
        val fontBtn = ui.tonal("") {}
        fun fontText() {
            fontBtn.text = SubtitleStyle.fontNames[Prefs.font(ctx).coerceIn(0, SubtitleStyle.fontNames.size - 1)] + "  ▾"
        }
        fontBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Yazı tipi").setItems(SubtitleStyle.fontNames) { _, which ->
                Prefs.setFont(ctx, which)
                fontText()
                restyle()
            }.show()
        }
        fontText()
        sub.addView(fontBtn, ui.lp(0, 8))

        val boldBtn = ui.tonal("") {}
        fun boldText() {
            boldBtn.text = if (Prefs.bold(ctx)) "Kalın: Açık" else "Kalın: Kapalı"
        }
        boldBtn.setOnClickListener {
            Prefs.setBold(ctx, !Prefs.bold(ctx))
            boldText()
            restyle()
        }
        boldText()
        sub.addView(boldBtn, ui.lp(0, 10))

        sub.addView(ui.label("Renk", 13f, Pal.MUTED), ui.lp(0, 6))
        val colorRow = LinearLayout(ctx)
        colorRow.orientation = LinearLayout.HORIZONTAL
        val chips = ArrayList<View>()
        fun chipStates() {
            for ((i, v) in chips.withIndex()) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(SubtitleStyle.colors[i])
                g.setStroke(ui.dp(3), if (i == Prefs.color(ctx)) Pal.ACCENT else Color.TRANSPARENT)
                v.background = g
            }
        }
        for (i in SubtitleStyle.colors.indices) {
            val v = View(ctx)
            v.setOnClickListener {
                Prefs.setColor(ctx, i)
                chipStates()
                restyle()
            }
            chips.add(v)
            val p = LinearLayout.LayoutParams(ui.dp(40), ui.dp(40))
            p.rightMargin = ui.dp(12)
            colorRow.addView(v, p)
        }
        chipStates()
        sub.addView(colorRow)
        SubtitleStyle.apply(ctx, preview, ui)
        root.addView(sub, ui.lp(0, 12))

        // ---- Seslendirme ----
        val dub = ui.card()
        dub.addView(ui.label("Seslendirme (Türkçe okuma)", 16f, Pal.TEXT, true), ui.lp(0, 10))
        val onSeg = Segmented(ui, ctx, listOf("Kapalı", "Açık")) { i ->
            Prefs.setDubOn(ctx, i == 1)
            if (i == 0) Dubber.get(ctx).stop()
        }
        onSeg.select(if (Prefs.dubOn(ctx)) 1 else 0)
        dub.addView(onSeg.view, ui.lp(0, 10))
        dub.addView(ui.label("Karakter sesleri", 12f, Pal.MUTED), ui.lp(0, 4))
        val autoSeg = Segmented(ui, ctx, listOf("Otomatik (isme göre)", "Tek ses")) { i ->
            Prefs.setDubAuto(ctx, i == 0)
        }
        autoSeg.select(if (Prefs.dubAuto(ctx)) 0 else 1)
        dub.addView(autoSeg.view, ui.lp(0, 4))
        dub.addView(ui.label("Altyazı \"Ad: konuşma\" biçimindeyse ad okunmaz. Ad erkek ya da kadın adına göre ses seçilir, aynı cinsiyetten farklı karakterler farklı ses alır.", 12f, Pal.MUTED), ui.lp(0, 10))
        dub.addView(ui.label("Ses kaynağı", 12f, Pal.MUTED), ui.lp(0, 4))
        val dubDesc = ui.label("", 12f, Pal.MUTED)
        val voiceBox = LinearLayout(ctx)
        voiceBox.orientation = LinearLayout.VERTICAL
        val rateBox = LinearLayout(ctx)
        rateBox.orientation = LinearLayout.VERTICAL

        fun refreshDub() {
            val g = Prefs.dubEngine(ctx) == "gemini"
            voiceBox.visibility = if (g) View.VISIBLE else View.GONE
            rateBox.visibility = if (g) View.GONE else View.VISIBLE
            dubDesc.text = if (g)
                "Çok daha doğal, ses tonu da yansır. Gemini anahtarı gerekir, her satırda 1-2 saniye gecikir. Hata olursa telefon sesine geçer."
            else
                "Telefonun Türkçe sesi. Anında okur, kalite telefona bağlı. Telefonda Türkçe ses yüklü olmalı."
        }
        val dEng = Segmented(ui, ctx, listOf("Telefon sesi", "Gemini sesi")) { i ->
            Prefs.setDubEngine(ctx, if (i == 1) "gemini" else "system")
            Dubber.get(ctx).stop()
            refreshDub()
        }
        dEng.select(if (Prefs.dubEngine(ctx) == "gemini") 1 else 0)
        dub.addView(dEng.view, ui.lp(0, 8))
        dub.addView(dubDesc, ui.lp(0, 10))

        val voices = arrayOf("Kore", "Puck", "Charon", "Fenrir", "Aoede", "Zephyr", "Orus", "Leda")
        val voiceLabels = arrayOf(
            "Kore (kadın, kararlı)", "Puck (erkek, neşeli)", "Charon (erkek, bilgilendirici)",
            "Fenrir (erkek, heyecanlı)", "Aoede (kadın, ferah)", "Zephyr (kadın, parlak)",
            "Orus (erkek, kararlı)", "Leda (kadın, genç)"
        )
        voiceBox.addView(ui.label("Varsayılan / anlatıcı sesi", 12f, Pal.MUTED), ui.lp(0, 4))
        val voiceBtn = ui.tonal("") {}
        fun voiceText() {
            val idx = voices.indexOf(Prefs.dubVoice(ctx)).let { if (it < 0) 0 else it }
            voiceBtn.text = voiceLabels[idx] + "  ▾"
        }
        voiceBtn.setOnClickListener {
            AlertDialog.Builder(ctx).setTitle("Ses").setItems(voiceLabels) { _, which ->
                Prefs.setDubVoice(ctx, voices[which])
                voiceText()
            }.show()
        }
        voiceText()
        voiceBox.addView(voiceBtn, ui.lp(0, 8))
        voiceBox.addView(ui.label("Ses modeli", 12f, Pal.MUTED), ui.lp(0, 4))
        voiceBox.addView(ui.field(Prefs.DEFAULT_TTS_MODEL, Prefs.dubModel(ctx), false) { Prefs.setDubModel(ctx, it) }, ui.lp(0, 4))
        dub.addView(voiceBox)

        val rateLabel = ui.label("Konuşma hızı: ${"%.1f".format(Prefs.dubRate(ctx) / 10f)}x", 13f, Pal.MUTED)
        rateBox.addView(rateLabel, ui.lp(0, 2))
        rateBox.addView(ui.seek(6, 20, Prefs.dubRate(ctx)) {
            Prefs.setDubRate(ctx, it)
            rateLabel.text = "Konuşma hızı: ${"%.1f".format(it / 10f)}x"
        }, ui.lp(0, 4))
        dub.addView(rateBox)
        refreshDub()

        dub.addView(ui.tonal("Sesi dene") {
            Dubber.get(ctx).speak("Merhaba, ben Türkçe seslendirme. Oyunun altyazısını sesli okuyacağım.")
        }, ui.lp(6, 8))
        dub.addView(ui.tonal("Kadın karakter dene") {
            Dubber.get(ctx).speak("Ayşe: Merhaba, ben bir kadın karakterim. Adım okunmamalı.")
        }, ui.lp(0, 8))
        dub.addView(ui.tonal("Erkek karakter dene") {
            Dubber.get(ctx).speak("Ahmet: Merhaba, ben bir erkek karakterim. Adım okunmamalı.")
        }, ui.lp(0, 8))
        dub.addView(ui.tonal("Karakter seslerini sıfırla") { Dubber.get(ctx).resetSpeakers() }, ui.lp(0, 8))
        dub.addView(ui.label("Sesi telefondan duyarsın. Kulaklık takarsan oyun sesiyle karışmaz.", 12f, Pal.MUTED))
        root.addView(dub, ui.lp(0, 12))

        // ---- Hız ----
        val spd = ui.card()
        spd.addView(ui.label("Okuma hızı", 16f, Pal.TEXT, true), ui.lp(0, 8))
        val sSeg = Segmented(ui, ctx, listOf("Hızlı", "Dengeli", "Tasarruf")) { Prefs.setSpeed(ctx, it) }
        sSeg.select(Prefs.speed(ctx).coerceIn(0, 2))
        spd.addView(sSeg.view, ui.lp(0, 6))
        spd.addView(ui.label("Hızlı: gecikme en düşük, telefon daha çok çalışır.", 12f, Pal.MUTED))
        root.addView(spd, ui.lp(0, 12))

        // ---- Yayın içi kontroller ----
        val pick = hooks.onPickRegion
        if (pick != null) {
            val st = ui.card()
            st.addView(ui.label("Yayın", 16f, Pal.TEXT, true), ui.lp(0, 10))
            st.addView(ui.primary("Okuma bölgesini seç") { pick() }, ui.lp(0, 8))
            hooks.onEditSubtitle?.let { f -> st.addView(ui.tonal("Altyazıyı elle ayarla (sürükle, büyüt)") { f() }, ui.lp(0, 8)) }
            hooks.onToggleCover?.let { f -> st.addView(ui.tonal("Ekranı karart / aç") { f() }, ui.lp(0, 8)) }
            hooks.onTogglePause?.let { f -> st.addView(ui.tonal("Çeviriyi duraklat / sürdür") { f() }) }
            root.addView(st, ui.lp(0, 12))
        }
        return root
    }
}
