package com.oyuncevir.ceviri

/** Derleme sırasında patch.py tarafından (GitHub Secrets'tan) doldurulur. Elle düzenleme. */
object EmbeddedKeys {
    val GEMINI: String = ""
    val DEEPL: String = ""
    val CLAUDE: String = ""
}
