package com.oyuncevir.ceviri

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.concurrent.Executors

/** Türkçe altyazıyı sesli okur: telefonun Türkçe sesi ya da Gemini TTS. */
class Dubber private constructor(private val app: Context) {

    companion object {
        @Volatile private var inst: Dubber? = null

        fun get(ctx: Context): Dubber =
            inst ?: synchronized(this) { inst ?: Dubber(ctx.applicationContext).also { inst = it } }
    }

    @Volatile var listener: ((String) -> Unit)? = null

    /** Bir karakterin sesi: cinsiyet, Gemini ses adı, telefon sesi için perde */
    class Prof(val gender: Char, val voice: String, val pitch: Float)

    private val femaleVoices = arrayOf("Kore", "Aoede", "Zephyr", "Leda", "Callirrhoe", "Autonoe")
    private val maleVoices = arrayOf("Puck", "Charon", "Fenrir", "Orus", "Enceladus", "Iapetus")
    private val femalePitch = floatArrayOf(1.18f, 1.32f, 1.06f, 1.25f, 1.12f, 1.38f)
    private val malePitch = floatArrayOf(0.82f, 0.68f, 0.95f, 0.74f, 0.88f, 0.62f)
    private val speakers = HashMap<String, Prof>()
    private var nextF = 0
    private var nextM = 0

    private val exec = Executors.newSingleThreadExecutor()
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var ttsBroken = false
    @Volatile private var pending: String? = null
    private var track: AudioTrack? = null
    private val trackLock = Any()
    @Volatile private var gen = 0
    @Volatile private var warnedNoKey = false
    private val cache = object : LinkedHashMap<String, Pair<ByteArray, Int>>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<ByteArray, Int>>?) = size > 40
    }

    fun speak(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        stop()
        val my = ++gen
        exec.execute {
            if (my != gen) return@execute
            val parts = SpeakerLabel.split(t)
            val body = parts.second.replace("\n", " ").trim()
            if (body.isEmpty()) return@execute
            val prof = profile(parts.first)
            if (my != gen) return@execute
            if (Prefs.dubEngine(app) == "gemini") speakGemini(body, prof.voice, my) else speakSystem(body, prof.pitch)
        }
    }

    /** Karakter-ses eşleşmelerini unutur */
    fun resetSpeakers() {
        synchronized(speakers) {
            speakers.clear()
            nextF = 0
            nextM = 0
        }
    }

    private fun defaultProf() = Prof('?', Prefs.dubVoice(app), 1.0f)

    private fun profile(name: String?): Prof {
        if (name == null || !Prefs.dubAuto(app)) return defaultProf()
        val key = name.lowercase(Locale("tr", "TR")).trim()
        synchronized(speakers) { speakers[key]?.let { return it } }
        var g = Names.guess(name)
        if (g == '?') {
            val r = classifyRemote(name)
            if (r == null) return defaultProf() // ağ hatası: önbelleğe alma, sonra tekrar dene
            g = r
        }
        val prof: Prof
        synchronized(speakers) {
            prof = when (g) {
                'F' -> {
                    val i = nextF++
                    Prof('F', femaleVoices[i % femaleVoices.size], femalePitch[i % femalePitch.size])
                }
                'M' -> {
                    val i = nextM++
                    Prof('M', maleVoices[i % maleVoices.size], malePitch[i % malePitch.size])
                }
                else -> defaultProf()
            }
            speakers[key] = prof
        }
        return prof
    }

    /** Sözlükte olmayan adlar için Gemini ya da Claude'a sorar. 'M', 'F', '?' ya da hata olursa null */
    private fun classifyRemote(name: String): Char? {
        val prompt = "Bir video oyununda \"$name\" adlı bir karakter konuşuyor. Bu ad çoğunlukla erkek mi yoksa " +
            "kadın bir karaktere mi ait? Sadece tek harfle cevap ver: E (erkek), K (kadın) ya da ? (emin değilsem)."
        val gKey = Prefs.apiKey(app)
        val cKey = Prefs.claudeKey(app)
        val r = when {
            gKey.isNotBlank() -> GeminiClient.generate(gKey, Prefs.model(app), prompt, 64)
            cKey.isNotBlank() -> ClaudeClient.generate(cKey, Prefs.claudeModel(app), prompt, 16)
            else -> return '?'
        }
        if (r.error != null) return null
        return when (r.text?.trim()?.firstOrNull()?.uppercaseChar()) {
            'E' -> 'M'
            'K' -> 'F'
            else -> '?'
        }
    }

    fun stop() {
        gen++
        pending = null
        synchronized(trackLock) {
            try {
                track?.stop()
                track?.release()
            } catch (e: Exception) {
            }
            track = null
        }
        try { tts?.stop() } catch (e: Exception) {}
    }

    // ---- Telefon sesi ----

    private fun speakSystem(t: String, pitch: Float = 1.0f) {
        if (ttsBroken) return
        val engine = tts
        if (engine == null) {
            pending = t
            tts = TextToSpeech(app) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("tr", "TR"))
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                    if (!ttsReady) {
                        ttsBroken = true
                        listener?.invoke("Telefonda Türkçe ses yok. Ayarlar > Dil > Metinden sese bölümünden Türkçe sesi indir")
                    } else {
                        val p = pending
                        pending = null
                        if (p != null) speakSystem(p, pitch)
                    }
                } else {
                    ttsBroken = true
                    listener?.invoke("Telefonun ses motoru başlatılamadı")
                }
            }
            return
        }
        if (!ttsReady) {
            pending = t
            return
        }
        engine.setSpeechRate(Prefs.dubRate(app) / 10f)
        engine.setPitch(pitch)
        engine.speak(t, TextToSpeech.QUEUE_FLUSH, null, "oyunca")
    }

    // ---- Gemini sesi ----

    /** exec iş parçacığında çalışır (bloklar) */
    private fun speakGemini(t: String, voice: String, my: Int) {
        val key = Prefs.apiKey(app)
        if (key.isBlank()) {
            if (!warnedNoKey) {
                warnedNoKey = true
                listener?.invoke("Gemini sesi için API anahtarı gerekli, telefon sesi kullanılıyor")
            }
            speakSystem(t)
            return
        }
        val model = Prefs.dubModel(app)
        val ck = voice + "|" + t
        val cached = synchronized(cache) { cache[ck] }
        val audio: Pair<ByteArray, Int>
        if (cached != null) {
            audio = cached
        } else {
            val r = GeminiClient.speech(key, model, voice, t)
            val pcm = r.pcm
            if (pcm == null) {
                if (my == gen) {
                    listener?.invoke(r.error ?: "Gemini sesi alınamadı")
                    speakSystem(t)
                }
                return
            }
            audio = Pair(pcm, r.rate)
            synchronized(cache) { cache[ck] = audio }
        }
        if (my == gen) playPcm(audio.first, audio.second)
    }

    private fun playPcm(pcm: ByteArray, rate: Int) {
        synchronized(trackLock) {
            try {
                track?.stop()
                track?.release()
            } catch (e: Exception) {
            }
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val at = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(min, pcm.size))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            at.write(pcm, 0, pcm.size)
            at.play()
            track = at
        }
    }
}
