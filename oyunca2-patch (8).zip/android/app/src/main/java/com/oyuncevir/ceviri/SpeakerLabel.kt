package com.oyuncevir.ceviri

/** Altyazının başındaki konuşmacı adını ayırır: "Ad: konuşma" ya da "AD" + yeni satır. */
object SpeakerLabel {
    private val colon = Regex("^\\s*(\\p{L}[\\p{L}0-9'’.\\- ]{0,27}?)\\s*[:：]\\s*(.+)$", RegexOption.DOT_MATCHES_ALL)
    private val notNames = hashSetOf(
        "dikkat", "not", "görev", "ipucu", "uyarı", "hedef", "bilgi", "önemli", "ses", "tip", "note",
        "warning", "objective", "hint", "info", "quest", "mission", "kontrol"
    )

    private fun looksLikeName(n: String): Boolean {
        if (n.length < 2) return false
        if (n.split(' ').size > 3) return false
        if (n.lowercase() in notNames) return false
        if (n.last() in ".?!,;") return false
        return true
    }

    /** (ad ya da null, söylenecek metin) */
    fun split(text: String): Pair<String?, String> {
        val t = text.trim()
        val m = colon.find(t)
        if (m != null) {
            val n = m.groupValues[1].trim()
            val body = m.groupValues[2].trim()
            if (body.isNotEmpty() && looksLikeName(n)) return Pair(n, body)
        }
        val nl = t.indexOf('\n')
        if (nl in 2..28) {
            val first = t.substring(0, nl).trim()
            val rest = t.substring(nl + 1).trim()
            val letters = first.filter { it.isLetter() }
            val upper = letters.isNotEmpty() && letters == letters.uppercase() && letters != letters.lowercase()
            if (rest.isNotEmpty() && looksLikeName(first) && upper) return Pair(first, rest)
        }
        return Pair(null, t)
    }
}
