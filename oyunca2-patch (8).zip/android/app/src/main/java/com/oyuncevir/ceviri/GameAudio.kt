package com.oyuncevir.ceviri

import android.content.Context
import android.system.Os

/**
 * Oyun sesini telefonda susturur. Yama, yayının ses koduna OYUNCA_MUTE ortam değişkenini okuyan
 * bir satır ekler; burada o değişkeni ayarlıyoruz.
 */
object GameAudio {
    fun apply(ctx: Context) {
        try {
            Os.setenv("OYUNCA_MUTE", if (Prefs.muteGame(ctx)) "1" else "0", true)
        } catch (e: Throwable) {
        }
    }
}
