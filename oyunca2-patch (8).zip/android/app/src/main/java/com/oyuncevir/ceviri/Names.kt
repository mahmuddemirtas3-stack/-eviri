package com.oyuncevir.ceviri

import java.util.Locale

/** Karakter adından cinsiyet tahmini. Bilinmeyen adlar için '?' döner. */
object Names {
    private val male = hashSetOf(
        "aaron", "adam", "adrian", "ahmet", "alan", "albert", "alex", "alexander", "alfred", "ali", "altair",
        "amca", "andrew", "andy", "anthony", "arthur", "atreus", "ayhan", "baba", "barret", "bay", "bayek",
        "ben", "benjamin", "bill", "billy", "bob", "bobby", "brad", "brian", "brother", "bruce", "burak",
        "can", "carl", "carlos", "cem", "charles", "charlie", "chris", "christian", "christopher",
        "cloud", "colin", "connor", "craig", "dad", "dan", "daniel", "danny",
        "dante", "dave", "david", "dean", "dede", "dennis", "derek", "dominic", "don", "donald",
        "doug", "drake", "dutch", "dylan", "ed", "eddie", "edward", "efendi", "emre", "eric", "ethan",
        "evan", "ezio", "father", "fatih", "frank", "franklin", "fred", "furkan", "gabriel", "gary", "gavin",
        "george", "geralt", "gordon", "grandpa", "greg", "gökhan", "görkem", "hakan",
        "halil", "hamza", "harold", "harry", "harun", "hasan", "henry", "hosea", "howard", "hüseyin", "ian",
        "ibrahim", "ilker", "isaac", "ismail", "jack", "jacob", "jake", "james", "jason", "javier", "jay",
        "jeff", "jeremy", "jerry", "jesse", "jim", "jimmy", "joe", "joel", "joey", "john", "johnny", "jon",
        "jonathan", "joseph", "josh", "joshua", "juan", "julian", "justin", "kaan", "kadir", "keith",
        "kemal", "ken", "kenan", "kerem", "kevin", "king", "koray", "kratos", "kyle", "larry", "lee",
        "lenny", "leo", "leon", "leonard", "levent", "liam", "logan", "lord", "louis", "luke", 
        "makarov", "marcus", "mark", "martin", "matt", "matthew", "max", "mehmet", "mert", "mesut", "metin",
        "micah", "michael", "mike", "mitchell", "mr", "murat", "mustafa", "nathan", "necati", "neil", "nero",
        "nicholas", "nick", "nihat", "noah", "oguz", "okan", "oliver", "onur", "orhan", "oscar",
        "osman", "owen", "oğuz", "patrick", "paul", "pete", "peter", "phil", "philip", "prince",
        "ralph", "ramazan", "randy", "ray", "raymond", "recep", "richard", "rick", "rob",
        "robert", "roger", "ron", "ronald", "ross", "roy", "russell", "ryan", "rıza", "sam", "samuel",
        "scott", "sean", "sebastian", "sedat", "selim", "semih", "sephiroth", "serkan", "seth",
        "shane", "simon", "sinan", "sir", "stan", "stephen", "steve", "steven", "sully",
        "süleyman", "taner", "tarık", "tayfun", "ted", "terry", "thomas", "tim", "timothy", "toby", "todd",
        "tolga", "tom", "tommy", "tony", "travis", "trevor", "turgut", "tyler", "ugur", "umut", "uncle",
        "uğur", "vedat", "veli", "vergil", "vic", "victor", "vincent", "volkan", "walter", "wayne", "will",
        "william", "yasin", "yavuz", "yiğit", "yusuf", "zach", "zack", "zafer", "zeki", "ömer", "özgür",
        "ünal"
    )

    private val female = hashSetOf(
        "abigail", "abla", "ada", "aerith", "alexandra", "alice", "alicia", "alison", "aloy", "alyx",
        "amanda", "amber", "amy", "andrea", "angela", "anna", "anne", "annie", "april", "ashley", "audrey",
        "aunt", "aya", "ayse", "ayşe", "barbara", "bayan", "beth", "betty", "beverly", "brenda", "brittany",
        "busra", "büşra", "carol", "caroline", "carolyn", "catherine", "cathy", "charlotte", "cheryl",
        "chloe", "christina", "christine", "cindy", "ciri", "claire", "clara", "claudia", "cynthia", "daisy",
        "dana", "deborah", "debra", "deniz", "derya", "diana", "diane", "dilara", "dilek", "donna",
        "dorothy", "ebru", "ece", "eda", "ela", "elena", "elif", "elizabeth", "ellen", "ellie", "emily",
        "emine", "emma", "erica", "esra", "eva", "evelyn", "faith", "fatma", "fiona", "frances", "gabriella",
        "gamze", "girl", "gizem", "gloria", "grace", "grandma", "gul", "gül", "gülsüm", "hande", "hanim",
        "hannah", "hanım", "hatice", "heather", "heidi", "helen", "holly", "hülya", "ilknur", "irem",
        "irene", "isabel", "isabella", "jackie", "jane", "janet", "janice", "jasmine", "jean", "jennifer",
        "jenny", "jessica", "jill", "joan", "joanna", "josephine", "joy", "judy", "julia", "julie", "kader",
        "karen", "kassandra", "kate", "katherine", "kathy", "katie", "kelly", "kim", "kimberly", "kübra",
        "kız", "lady", "lara", "laura", "lauren", "leah", "lena", "leyla", "lily", "linda", "lisa", "lois",
        "lori", "louise", "lucia", "lucy", "lydia", "lynn", "margaret", "maria", "marie", "marilyn",
        "martha", "mary", "megan", "melis", "melissa", "meltem", "merve", "michelle", "miss", "molly", "mom",
        "monica", "mother", "mrs", "ms", "nancy", "natalie", "natasha", "neslihan", "nicole", "nina", "nine",
        "nur", "nuray", "olivia", "pamela", "patricia", "paula", "peach", "penny", "pinar", "princess",
        "pınar", "queen", "rabia", "rachel", "rebecca", "rose", "rukiye", "ruth", "sadie", "sally",
        "samantha", "samus", "sandra", "sara", "sarah", "seda", "selin", "sema", "sevda", "sevgi", "sevil",
        "sevim", "sharon", "sheila", "shirley", "sibel", "sister", "songül", "sophia", "sophie", "stephanie",
        "sule", "sultan", "susan", "suzanne", "sylvia", "tanya", "teresa", "teyze", "tifa", "tiffany",
        "tina", "tracy", "triss", "tugba", "tuğba", "tülin", "valerie", "vanessa", "victoria", "violet",
        "virginia", "wendy", "woman", "yagmur", "yağmur", "yeliz", "yennefer", "yıldız", "zehra", "zelda",
        "zeynep", "zübeyde", "özlem", "şule"
    )

    private val tr = Locale("tr", "TR")

    private fun tokens(name: String): List<String> =
        name.lowercase(tr).split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }

    /** 'M', 'F' ya da '?' */
    fun guess(name: String): Char {
        val ts = tokens(name)
        if (ts.isEmpty()) return '?'
        // Unvanlar ve sıfatlar önce
        for (t in ts) {
            if (t in titlesM) return 'M'
            if (t in titlesF) return 'F'
        }
        val first = ts[0]
        if (first in male) return 'M'
        if (first in female) return 'F'
        for (t in ts) {
            if (t in male) return 'M'
            if (t in female) return 'F'
        }
        return '?'
    }

    private val titlesM = hashSetOf(
        "amca", "baba", "bay", "brother", "dad", "dede", "efendi", "father", "king", "lord", 
        "mr", "prince", "sir", "uncle"
    )

    private val titlesF = hashSetOf(
        "abla", "anne", "aunt", "bayan", "girl", "hanim", "hanım", "lady", "miss", "mom", "mother", "mrs",
        "ms", "nine", "princess", "queen", "sister", "teyze", "woman"
    )
}
