package com.oyuncevir.ceviri

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiResult(val text: String?, val error: String?)

class SpeechResult(val pcm: ByteArray?, val rate: Int, val error: String?)

object GeminiClient {
    fun generate(apiKey: String, model: String, prompt: String, maxTokens: Int = 1024): GeminiResult {
        var conn: HttpURLConnection? = null
        try {
            val parts = JSONArray().put(JSONObject().put("text", prompt))
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", maxTokens))
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 5000
            conn.readTimeout = 12000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val hint = when (code) {
                    400 -> "model adı ya da anahtar hatalı olabilir"
                    401, 403 -> "API anahtarı geçersiz"
                    404 -> "model bulunamadı, model adını kontrol et"
                    429 -> "istek sınırı doldu"
                    else -> "sunucu hatası"
                }
                return GeminiResult(null, "Gemini hatası ($code): $hint")
            }
            val cands = JSONObject(resp).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) return GeminiResult("", null)
            val out = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (out != null) for (i in 0 until out.length()) sb.append(out.getJSONObject(i).optString("text", ""))
            return GeminiResult(sb.toString().trim(), null)
        } catch (e: Exception) {
            return GeminiResult(null, "Gemini'ye ulaşılamadı")
        } finally {
            // bağlantı açık kalır: sonraki istek TLS el sıkışması beklemez
        }
    }

    /** Gemini TTS: metni sese çevirir. Dönen veri ham PCM (16 bit, tek kanal). */
    fun speech(apiKey: String, model: String, voice: String, text: String): SpeechResult {
        var conn: HttpURLConnection? = null
        try {
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", "Doğal ve akıcı bir tonda, bir oyun karakteri gibi Türkçe oku: $text")
                ))))
                .put("generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put(
                        "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 5000
            conn.readTimeout = 20000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val hint = when (code) {
                    400 -> "model ya da ses adı hatalı"
                    401, 403 -> "API anahtarı geçersiz"
                    404 -> "ses modeli bulunamadı"
                    429 -> "istek sınırı doldu"
                    else -> "sunucu hatası"
                }
                return SpeechResult(null, 24000, "Gemini sesi ($code): $hint")
            }
            val parts = JSONObject(resp).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: continue
                    val data = inline.optString("data", "")
                    if (data.isEmpty()) continue
                    val mime = inline.optString("mimeType", inline.optString("mime_type", ""))
                    val m = Regex("rate=(\\d+)").find(mime)
                    val rate = m?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                    return SpeechResult(android.util.Base64.decode(data, android.util.Base64.DEFAULT), rate, null)
                }
            }
            return SpeechResult(null, 24000, "Gemini ses döndürmedi")
        } catch (e: Exception) {
            return SpeechResult(null, 24000, "Gemini sesine ulaşılamadı")
        } finally {
            // bağlantı açık kalır: sonraki istek TLS el sıkışması beklemez
        }
    }
}
