"""Momiji'yi tek uygulamaya (Oyunca) dönüştürür: çeviri servisi + yeni ad/simge + tek açılış ekranı."""
import pathlib
import re
import sys

root = pathlib.Path(".")
APP = "Çeviri"

man = root / "android/app/src/main/AndroidManifest.xml"
if not man.exists():
    sys.exit("HATA: AndroidManifest.xml bulunamadi: %s" % man)
m = man.read_text(encoding="utf-8")

# ---- app/build.gradle(.kts) ----
gfile = None
for name in ("build.gradle.kts", "build.gradle"):
    p = root / "android/app" / name
    if p.exists():
        gfile = p
        break
if gfile is None:
    sys.exit("HATA: android/app/build.gradle(.kts) bulunamadi")
g = gfile.read_text(encoding="utf-8")

# Paket adi (Momiji'nin etkinlik adlarini tam sinif adina cevirmek icin)
ns = None
mm = re.search(r'namespace\s*=?\s*["\']([^"\']+)["\']', g)
if mm:
    ns = mm.group(1)
else:
    mp = re.search(r'<manifest[^>]*\spackage="([^"]+)"', m)
    if mp:
        ns = mp.group(1)

if "com.oyuncevir.ceviri" in m:
    print("Manifest zaten yamali")
else:
    # 1) Momiji'nin kendi acilis simgesini kaldir: tek simge Oyunca olsun
    #    (PS5 baglantisi Ps5Launcher.kt ile dogrudan Momiji'nin ana ekranina acilir)
    m = re.sub(
        r'<category\s+android:name="android\.intent\.category\.LAUNCHER"\s*/>',
        "", m)

    # 3) Uygulama adi ve simgesi
    a = m.find("<application")
    b = m.find(">", a)
    tag = m[a:b]
    tag = re.sub(r'\s+android:(icon|roundIcon)="[^"]*"', "", tag)
    if re.search(r'android:label="[^"]*"', tag):
        tag = re.sub(r'android:label="[^"]*"', 'android:label="%s"' % APP, tag)
    else:
        tag += '\n        android:label="%s"' % APP
    tag += '\n        android:icon="@drawable/oyunca_icon"'
    m = m[:a] + tag + m[b:]

    # 4) Bilesenler
    comps = """
        <activity
            android:name="com.oyuncevir.ceviri.CeviriActivity"
            android:exported="true"
            android:label="Çeviri"
            android:theme="@android:style/Theme.Material.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    """
    j = m.rfind("</application>")
    if j < 0:
        sys.exit("HATA: </application> etiketi bulunamadi")
    m = m[:j] + comps + m[j:]
    man.write_text(m, encoding="utf-8")
    print("Manifest yamalandi")

# ---- Gradle bagimliliklari ----
if "mlkit:translate" not in g:
    mm = re.search(r"^dependencies\s*\{", g, re.M)
    if not mm:
        sys.exit("HATA: dependencies blogu bulunamadi: %s" % gfile)
    deps = (
        '\n    implementation("com.google.mlkit:text-recognition:16.0.1")'
        '\n    implementation("com.google.mlkit:translate:17.0.3")'
    )
    g = g[: mm.end()] + deps + g[mm.end():]
    gfile.write_text(g, encoding="utf-8")
    print("Gradle yamalandi:", gfile)
else:
    print("Gradle zaten yamali")

# ---- Gorunen "Momiji" yazilari ----
for sf in (root / "android/app/src/main/res").glob("values*/strings.xml"):
    try:
        s = sf.read_text(encoding="utf-8")
        s2 = s.replace("Momiji", APP).replace("MOMIJI", APP.upper())
        if s2 != s:
            sf.write_text(s2, encoding="utf-8")
            print("Ad degistirildi:", sf)
    except Exception as e:
        print("Uyari:", sf, e)


# ---- Yayin ekrani (StreamActivity) kancasi ----
sa = None
for f in (root / "android/app/src/main/java").rglob("StreamActivity.kt"):
    sa = f
    break
if sa is None:
    sys.exit("HATA: StreamActivity.kt bulunamadi")
s = sa.read_text(encoding="utf-8")
if "OyuncaHost" in s:
    print("StreamActivity zaten yamali")
else:
    n1 = s.count("setContentView(binding.root)")
    s, c1 = re.subn(
        r"(setContentView\(binding\.root\))",
        r"\1\n\t\tcom.oyuncevir.ceviri.OyuncaHost.attach(this)", s, count=1)
    s, c2 = re.subn(
        r"(override fun onDestroy\(\)\s*\{)",
        r"\1\n\t\tcom.oyuncevir.ceviri.OyuncaHost.detach(this)", s, count=1)
    if c1 != 1 or c2 != 1:
        sys.exit("HATA: StreamActivity kancasi eklenemedi (%d, %d)" % (c1, c2))
    sa.write_text(s, encoding="utf-8")
    print("StreamActivity yamalandi:", sa)

# ---- Ekrandaki oyun tuslari hicbir yoldan acilmasin (bu bir Remote Play oyunu degil, monitorde oynaniyor) ----
pf = None
for f in (root / "android/app/src/main/java").rglob("Preferences.kt"):
    pf = f
    break
if pf is not None:
    t = pf.read_text(encoding="utf-8")
    t2, c = re.subn(
        r"(var onScreenControlsEnabled\s*\n\s*)get\(\)\s*=\s*sharedPreferences\.getBoolean\(onScreenControlsEnabledKey,\s*!isTv\)",
        r"\1get() = false", t, count=1)
    if c == 1:
        pf.write_text(t2, encoding="utf-8")
        print("Ekran tuslari kapatildi:", pf)
    else:
        print("Uyari: ekran tuslari kapatilamadi (kalip bulunamadi)")

# ---- Gomulu API anahtarlari (GitHub Secrets'tan; yoksa bos kalir) ----
import os

def _clean(name):
    return re.sub(r"[^A-Za-z0-9_\-:.]", "", os.environ.get(name, ""))

ek = root / "android/app/src/main/java/com/oyuncevir/ceviri/EmbeddedKeys.kt"
if ek.parent.exists():
    g, d, c = _clean("OYUNCA_GEMINI_KEY"), _clean("OYUNCA_DEEPL_KEY"), _clean("OYUNCA_CLAUDE_KEY")
    ek.write_text(
        "package com.oyuncevir.ceviri\n\n"
        "object EmbeddedKeys {\n"
        '    val GEMINI: String = "%s"\n'
        '    val DEEPL: String = "%s"\n'
        '    val CLAUDE: String = "%s"\n'
        "}\n" % (g, d, c), encoding="utf-8")
    print("Gomulu anahtarlar: gemini=%s deepl=%s claude=%s" % (bool(g), bool(d), bool(c)))

# ---- Debug derlemesini "hata ayiklanabilir" olmaktan cikar (antivirus sezgilerini azaltir) ----
bg = root / "android/app/build.gradle"
if bg.exists():
    t = bg.read_text(encoding="utf-8")
    if "debuggable false" not in t:
        t2, c = re.subn(r"(buildTypes\s*\{)", r"\1\n        debug {\n            debuggable false\n        }", t, count=1)
        if c == 1:
            bg.write_text(t2, encoding="utf-8")
            print("debuggable kapatildi")

# ---- Oyun sesi telefonda susturulabilsin (OYUNCA_MUTE ortam degiskeni, uygulama ayarindan yonetilir) ----
ao = root / "android/app/src/main/cpp/audio-output.cpp"
if ao.exists():
    c = ao.read_text(encoding="utf-8")
    if "OYUNCA_MUTE" not in c:
        snippet = "\tsize_t buf_size = samples_count * sizeof(int16_t);\n"
        if c.count(snippet) == 1:
            c = c.replace(
                snippet,
                snippet
                + "\t{\n"
                + "\t\tconst char *oyunca_mute = getenv(\"OYUNCA_MUTE\");\n"
                + "\t\tif(oyunca_mute && oyunca_mute[0] == '1')\n"
                + "\t\t\tmemset(buf, 0, buf_size);\n"
                + "\t}\n", 1)
            c = "#include <stdlib.h>\n#include <string.h>\n" + c
            ao.write_text(c, encoding="utf-8")
            print("Oyun sesi susturma yamasi eklendi")
        else:
            print("Uyari: ses yamasi icin kalip bulunamadi")
