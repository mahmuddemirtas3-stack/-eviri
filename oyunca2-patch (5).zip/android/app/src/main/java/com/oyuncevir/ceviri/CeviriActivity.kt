package com.oyuncevir.ceviri

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.ImageView
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Oyunca ana menüsü (Momiji'nin görünümünde): PS5'e bağlan ve çeviri ayarları. */
class CeviriActivity : Activity() {

    private lateinit var ui: UiKit
    private lateinit var consoleTitle: TextView
    private lateinit var consoleSub: TextView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = UiKit(this)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(ui.dp(16), ui.dp(40), ui.dp(16), ui.dp(24))
        root.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(
                ui.dp(16), insets.systemWindowInsetTop + ui.dp(16),
                ui.dp(16), insets.systemWindowInsetBottom + ui.dp(24)
            )
            insets
        }

        // Başlık: simge + ad
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        try {
            val iv = ImageView(this)
            iv.setImageBitmap(BitmapFactory.decodeStream(assets.open("hero.png")))
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            head.addView(iv, LinearLayout.LayoutParams(ui.dp(84), ui.dp(84)).apply { rightMargin = ui.dp(16) })
        } catch (e: Exception) {
        }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = ui.label("ÇEVİRİ", 32f, Pal.TEXT, true)
        title.letterSpacing = 0.12f
        titles.addView(title)
        val lam = ui.label("λ  Oyunlara anlık Türkçe altyazı", 13f, Pal.ACCENT, true)
        titles.addView(lam, ui.lp(2, 0))
        head.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(head, ui.lp(0, 8))

        // turuncu ayraç
        val bar = android.view.View(this)
        bar.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Pal.ACCENT, 0x00FF9A1F)
        )
        root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ui.dp(3)).apply { bottomMargin = ui.dp(18) })

        // Konsol kartı
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        val hg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF1F3A40.toInt(), 0xFF141D21.toInt()))
        hg.cornerRadius = ui.dp(26).toFloat()
        hg.setStroke(ui.dp(1), 0x66FF9A1F)
        hero.background = hg
        hero.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(20))
        val tag = ui.label("PLAYSTATION 5", 11f, Pal.TEAL, true)
        tag.letterSpacing = 0.2f
        hero.addView(tag)
        consoleTitle = ui.label("", 24f, Pal.TEXT, true)
        consoleSub = ui.label("", 13f, Pal.MUTED)
        hero.addView(consoleTitle, ui.lp(4, 0))
        hero.addView(consoleSub, ui.lp(2, 18))
        hero.addView(ui.primary("▶   OYNA") { play() }, ui.lp(0, 10))
        hero.addView(ui.tonal("Konsol ekle / yönet") { startActivity(Ps5Launcher.manageIntent(this)) })
        root.addView(hero, ui.lp(0, 14))

        // Kullanım
        val help = ui.card()
        help.addView(ui.label("Nasıl çalışır", 16f, Pal.TEXT, true), ui.lp(0, 8))
        help.addView(
            ui.label(
                "• Oyna'ya bas, PS5'e bağlanır. Yayın telefonda açılır, sen monitörde kumandayla oynarsın.\n" +
                    "• Ekranın sol kenarından sağa çek: ayarlar. Orada \"Okuma bölgesini seç\" ile altyazının çıktığı yeri çiz.\n" +
                    "• Sağ kenardan sola çek: ekranı karart. Telefon ekranı siyah olsa da okuma ve altyazı sürer.\n" +
                    "• İlk seferde \"Konsol ekle / yönet\"ten PS5'ini ekle.",
                13f, Pal.MUTED
            )
        )
        root.addView(help, ui.lp(0, 14))

        // Ayarlar
        root.addView(SettingsPanel.build(this, ui, SettingsHooks()), ui.lp(0, 0))

        val scroll = ScrollView(this)
        scroll.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF12262B.toInt(), Pal.BG, Pal.BG))
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val n = Ps5Launcher.consoleName(this)
        consoleTitle.text = n ?: "Konsol seçilmedi"
        consoleSub.text = if (n != null) "Son oynanan konsol, otomatik bağlanır" else "Önce \"Konsol ekle / yönet\"ten PS5'ini ekle"
    }

    private fun play() {
        if (Ps5Launcher.consoleName(this) == null) {
            Toast.makeText(this, "Önce konsolunu ekle", Toast.LENGTH_LONG).show()
        }
        try {
            startActivity(Ps5Launcher.playIntent(this))
        } catch (e: Exception) {
            Toast.makeText(this, "Bağlantı ekranı açılamadı", Toast.LENGTH_LONG).show()
        }
    }
}
