package com.oyuncevir.ceviri

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ClaudeClient {
    fun generate(apiKey: String, model: String, prompt: String, maxTokens: Int = 512): GeminiResult {
        var conn: HttpURLConnection? = null
        try {
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", maxTokens)
                .put("temperature", 0.2)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 5000
            conn.readTimeout = 12000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val hint = when (code) {
                    400 -> "model adı hatalı ya da bakiye yetersiz"
                    401, 403 -> "API anahtarı geçersiz"
                    404 -> "model bulunamadı, model adını kontrol et"
                    429 -> "istek sınırı doldu"
                    else -> "sunucu hatası"
                }
                return GeminiResult(null, "Claude hatası ($code): $hint")
            }
            val content = JSONObject(resp).optJSONArray("content")
            val sb = StringBuilder()
            if (content != null) for (i in 0 until content.length()) sb.append(content.getJSONObject(i).optString("text", ""))
            return GeminiResult(sb.toString().trim(), null)
        } catch (e: Exception) {
            return GeminiResult(null, "Claude'a ulaşılamadı")
        } finally {
            conn?.disconnect()
        }
    }
}
